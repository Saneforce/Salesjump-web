﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Routing;

namespace WebaApi.Controllers
{
    public class UserInput
    {
        public  string Name { get; set; }
        public  string Age { get; set; }
        public  string Address { get; set; }

    }
    
    public class InsertController : ApiController
    {
        [HttpPost]
        [Route("api/Insert")]
        public HttpResponseMessage Add([FromBody] UserInput param)
        {
            //string connectionString;

            SqlConnection conn;
            SqlCommand command;

            try
            {
                /*using connection string from webconfig use this
                conn = new SqlConnection( ConfigurationManager.ConnectionStrings["sqlservername"].ToString());*/
                
                /*using direct sqlIP and password means use this
                 conn = new SqlConnection(@"Data Source=sqlservername;Initial Catalog=dbname;User Name = sqlusername ; Password = sqlpassword;Integrated Security=True");*/

                conn = new  SqlConnection(@"Data Source=DESKTOP-CKLE8PR;Initial Catalog=Testuser;Integrated Security=True");
                command = new SqlCommand();

                command = new SqlCommand("InsertData", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Name", param.Name);
                command.Parameters.AddWithValue("@Age", param.Age);
                command.Parameters.AddWithValue("@Address", param.Address);
                conn.Open();
                int i = command.ExecuteNonQuery();
                conn.Close();
                if (i >= 1)
                {
                    return  Request.CreateResponse(HttpStatusCode.OK, "New User Inserted Successfully"); 

                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound,"User Not Inserted");

                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("api/retrieve_data")]
        public HttpResponseMessage Retrieve(string Name)
        {
            string responseString;

            DataTable dataTable;
            SqlConnection conn;
            SqlCommand command;
            SqlDataAdapter dataAdapter;

            dataTable = new DataTable();
            conn = new SqlConnection();
            command = new SqlCommand();

            try
            {
                /*using connection string from webconfig use this
               conn = new SqlConnection( ConfigurationManager.ConnectionStrings["sqlservername"].ToString());*/

                /*using direct sqlIP and password means use this
                 conn = new SqlConnection(@"Data Source=sqlservername;Initial Catalog=dbname;User Name = sqlusername ; Password = sqlpassword;Integrated Security=True");*/

                conn = new SqlConnection(@"Data Source=DESKTOP-CKLE8PR;Initial Catalog=Testuser;Integrated Security=True");
                command.Connection = conn;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = "retrieveData";
                command.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = Name;
                
                conn.Open();
                dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                dataAdapter.Dispose();

                responseString = (@"[" + String.Join(",", dataTable.AsEnumerable().Select(row => row.Field<String>(1)).ToArray()) + "]").Replace(@"\", @"\\");
                conn.Close();

                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.ClearHeaders();
                HttpContext.Current.Response.AddHeader("content-disposition", "Data");
                HttpContext.Current.Response.ContentType = "application/json";
                HttpContext.Current.Response.Write(responseString);
                HttpContext.Current.Response.End();

                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
