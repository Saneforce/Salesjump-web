SalesForce.cs

public string SaveNewTravelMode(SaveSalesForce sd)
        {
            string msg = string.Empty;
            try
            {
                SqlParameter[] parameters = new SqlParameter[]
                     {
                        new SqlParameter("@Divcode", sd.divcode),
                        new SqlParameter("@Mode", sd.mode),
                        new SqlParameter("@Charge", sd.charge),
                        new SqlParameter("@Meter", sd.meter),
                        new SqlParameter("@Driver", sd.driver),
                        new SqlParameter("@Echange", sd.echange),                        
                        new SqlParameter("@Allowance", (sd.allowance.ToString()).TrimEnd(','))
                     };
                using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["Ereportcon"].ToString()))
                {
                    using (SqlCommand cmd = con.CreateCommand())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "insertTravelMode";
                        cmd.Parameters.AddRange(parameters);

                        try
                        {
                            if (con.State != ConnectionState.Open)
                            {
                                con.Open();
                            }

                            cmd.ExecuteNonQuery();
                            msg = "Success";
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.Message;
            }
            return msg;

        }
		
		
Asset.cs
		
public int DeActivateTravel(string plcode, string stus)
        {
            int iReturn = -1;
            try
            {
                DB_EReporting db = new DB_EReporting();
                strQry = "update Mas_Modeof_Travel set Active_Flag = '" + stus + "' where Sl_No = '" + plcode + "'";
                iReturn = db.ExecQry(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return iReturn;
        }
		
AdminSetup.cs
		
public DataSet getTravel_ModeFields(string Div)
        {
            DB_EReporting db_ER = new DB_EReporting();

            DataSet dsAdmin = null;

            strQry = "exec getTravel_ModeFields "+ Div + "";

            try
            {
                dsAdmin = db_ER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsAdmin;
        }