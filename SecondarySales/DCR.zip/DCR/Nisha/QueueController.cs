﻿using msvInterface;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;

namespace QueueMonitoring.Controllers
{
    public class Queue_Parameter
    {
        public string user_id { get; set; }
        public string client_id { get; set; }
        public string locale_id { get; set; }
        public string country_code { get; set; }
        public string file_name { get; set; }
        public string status { get; set; }
    }
    public class QueueController : ApiController
    {
        [HttpPost]
        [Route("api/insert_file_into_DB")]
        public HttpResponseMessage QueueInsert([FromBody] Queue_Parameter param)
        {
            string filePath, appRoot, fileContent, connectionString;

            appRoot = AppDomain.CurrentDomain.BaseDirectory;
            filePath = appRoot + "\\" + "content_store" + "\\" + param.client_id + "\\" + param.country_code + "\\" + "QueueManager" + "\\" + param.user_id + "\\" + "exception" + "\\" + param.file_name;
            fileContent = " ";

            SqlConnection conn;
            SqlCommand command;

            conn = new SqlConnection();
            command = new SqlCommand();

            try
            {
                connectionString = WebConfigurationManager.ConnectionStrings["conn_" + param.client_id + "app"].ConnectionString;
                if (File.Exists(filePath))
                {
                    fileContent = File.ReadAllText(filePath);
                    fileContent = fileContent.Replace("}\r\n\r\n{", ",").Replace("\"", "").Replace("\\", "");

                    conn.ConnectionString = connectionString;
                    command.Connection = conn;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    command.CommandText = "sp_save_manage_exception_file";
                    command.Parameters.Add("@i_user_id", SqlDbType.NVarChar, 12).Value = param.user_id;
                    command.Parameters.Add("@i_client_id", SqlDbType.VarChar, 20).Value = param.client_id;
                    command.Parameters.Add("@i_locale_id", SqlDbType.VarChar, 5).Value = param.locale_id;
                    command.Parameters.Add("@i_country_code", SqlDbType.VarChar, 3).Value = param.country_code;
                    command.Parameters.Add("@i_file_name", SqlDbType.VarChar, 50).Value = param.file_name;
                    command.Parameters.Add("@i_file_content", SqlDbType.NVarChar, 3500).Value = fileContent;
                    command.Parameters.Add("@i_received_date_time", SqlDbType.NVarChar, 30).Value = DateTime.Now.ToString("dd.MMM.yyyy  hh:mm:ss tt");
                    command.Parameters.Add("@i_resolved_date_time", SqlDbType.NVarChar, 30).Value = " ";
                    command.Parameters.Add("@i_save_mode", SqlDbType.VarChar, 1).Value = 'A';

                    conn.Open();

                    command.ExecuteNonQuery();

                    conn.Close();
                    return Request.CreateResponse(HttpStatusCode.OK, "Data successfully inserted");
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.OK, "File not exsist");
                }
            }
            catch (Exception ex)
            {
                msvUtil.LogException(AppDomain.CurrentDomain.BaseDirectory, param.client_id, param.country_code, "QueueMonitor", ex.Message, ex.StackTrace);
                return null;
            }
        }

        [HttpPost]
        [Route("api/update_file_into_DB")]
        public HttpResponseMessage QueueUpdate([FromBody] Queue_Parameter param)
        {
            string connectionString;

            SqlConnection conn;
            SqlCommand command;

            conn = new SqlConnection();
            command = new SqlCommand();

            try
            {
                connectionString = WebConfigurationManager.ConnectionStrings["conn_" + param.client_id + "app"].ConnectionString;
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = "sp_save_manage_exception_file";
                command.Parameters.Add("@i_user_id", SqlDbType.NVarChar, 12).Value = param.user_id;
                command.Parameters.Add("@i_client_id", SqlDbType.VarChar, 20).Value = param.client_id;
                command.Parameters.Add("@i_locale_id", SqlDbType.VarChar, 5).Value = param.locale_id;
                command.Parameters.Add("@i_country_code", SqlDbType.VarChar, 3).Value = param.country_code;
                command.Parameters.Add("@i_file_name", SqlDbType.VarChar, 50).Value = param.file_name;
                command.Parameters.Add("@i_file_content", SqlDbType.NVarChar, 3500).Value = "";
                command.Parameters.Add("@i_received_date_time", SqlDbType.NVarChar, 30).Value = "";
                command.Parameters.Add("@i_resolved_date_time", SqlDbType.NVarChar, 30).Value = DateTime.Now.ToString("dd.MMM.yyyy  hh:mm:ss tt");
                command.Parameters.Add("@i_save_mode", SqlDbType.VarChar, 1).Value = 'U';

                conn.Open();
                command.ExecuteNonQuery();
                conn.Close();

                return Request.CreateResponse(HttpStatusCode.OK, "Resolved Date updated successfully ");
            }
            catch (Exception ex)
            {
                msvUtil.LogException(AppDomain.CurrentDomain.BaseDirectory, param.client_id, param.country_code, "QueueMonitor", ex.Message, ex.StackTrace);
                return null;
            }
        }

        [HttpPost]
        [Route("api/retrieve_file_from_DB")]
        public HttpResponseMessage QueueRetrieve([FromBody] Queue_Parameter param)
        {
            string appRoot, connectionString, responseString;

            appRoot = AppDomain.CurrentDomain.BaseDirectory;
            DataTable dataTable;
            SqlConnection conn;
            SqlCommand command;
            SqlDataAdapter dataAdapter;

            dataTable = new DataTable();
            conn = new SqlConnection();
            command = new SqlCommand();

            try
            {
                connectionString = WebConfigurationManager.ConnectionStrings["conn_" + param.client_id + "app"].ConnectionString;

                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = "sp_retrieve_manage_exception_file";
                command.Parameters.Add("@i_user_id", SqlDbType.NVarChar, 12).Value = param.user_id;
                command.Parameters.Add("@i_client_id", SqlDbType.VarChar, 20).Value = param.client_id;
                command.Parameters.Add("@i_locale_id", SqlDbType.VarChar, 5).Value = param.locale_id;
                command.Parameters.Add("@i_country_code", SqlDbType.VarChar, 3).Value = param.country_code;

                if (param.status == "F")
                {
                    command.Parameters.Add("@i_file_name", SqlDbType.VarChar, 50).Value = param.file_name;
                    command.Parameters.Add("@i_status", SqlDbType.NVarChar, 2).Value = "F";
                }
                if (param.status == "R")
                {
                    command.Parameters.Add("@i_file_name", SqlDbType.VarChar, 50).Value = "";
                    command.Parameters.Add("@i_status", SqlDbType.NVarChar, 2).Value = "R";
                }
                if (param.status == "UR")
                {
                    command.Parameters.Add("@i_file_name", SqlDbType.VarChar, 50).Value = "";
                    command.Parameters.Add("@i_status", SqlDbType.NVarChar, 2).Value = "UR";
                }

                conn.Open();
                dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                dataAdapter.Dispose();
                if (param.status == "F")
                {
                    responseString = (@"[" + String.Join(",", dataTable.AsEnumerable().Select(row => row.Field<String>(1)).ToArray()) + "]");
                }
                else
                {
                    responseString = (@"[" + String.Join(",", dataTable.AsEnumerable().Select(row => row.Field<String>(1)).ToArray()) + "]").Replace(@"\", @"\\");
                }
                conn.Close();

                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.ClearHeaders();
                HttpContext.Current.Response.AddHeader("content-disposition", "QueueData");
                HttpContext.Current.Response.ContentType = "application/json";
                HttpContext.Current.Response.Write(responseString);
                HttpContext.Current.Response.End();

                return null;
            }
            catch (Exception ex)
            {
                msvUtil.LogException(AppDomain.CurrentDomain.BaseDirectory, param.client_id, param.country_code, "QueueMonitor", ex.Message, ex.StackTrace);
                return null;
            }
        }
    }
}
