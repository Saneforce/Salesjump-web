﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Xml;

namespace JsonExport.Controllers
{

    public class Export_Parameter
    {
        public string session_id { get; set; }
        public string user_id { get; set; }
        public string client_id { get; set; }
        public string locale_id { get; set; }
        public string country_code { get; set; }
        public string document_type { get; set; }
        public string document_template { get; set; }
        public string data_retrieve_service_name { get; set; }
        public string data_retrieve_request_xml { get; set; }

    }
    public class ExportController : ApiController
    {
        //[System.Web.Http.HttpGet]
        [HttpPost]
        [Route("api/export")]
         public HttpResponseMessage Export([FromBody] Export_Parameter param )
        {
            string ConnectionString, header, jsonKey, jsonVal, jsonString, FilePath;
            XmlDocument xDoc;

            ConnectionString = null;
            header = null;
            jsonKey = null;
            jsonVal = null;
            jsonString = "";
            FilePath = @"E:/Export/asset_master.csv";

            xDoc = new XmlDocument();
            var contentList = new List<string>();
            StringWriter sw = new StringWriter();
            StringBuilder sb = new StringBuilder();

            ConnectionString = @"Data Source = peg-5\sqlexpress ; User Id = sa; Password = sa@123 ; Initial Catalog = msv_export; Integrated Security = True";
            xDoc.LoadXml(param.data_retrieve_request_xml);

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    command.CommandText = param.data_retrieve_service_name;
                  //command.Parameters.Add("@i_session_id", SqlDbType.UniqueIdentifier).Value = new Guid(param.session_id);
                    command.Parameters.Add("@i_user_id", SqlDbType.NVarChar, 12).Value = param.user_id;
                    command.Parameters.Add("@i_client_id", SqlDbType.VarChar, 20).Value = param.client_id;
                    command.Parameters.Add("@i_locale_id", SqlDbType.VarChar, 5).Value = param.locale_id;
                    command.Parameters.Add("@i_country_code", SqlDbType.VarChar, 3).Value = param.country_code;

                    /* FORMING THE DYNAMIC SQL PARAMETERS */
                 /*    foreach (XmlNode childNode in xDoc.SelectSingleNode("signature").ChildNodes)
                     {
                         if (childNode.Name.IndexOf("o_") == 0)
                         {
                             command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 5).Direction = ParameterDirection.Output;
                         }
                         else
                         {
                             command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 2500).Value = childNode.InnerXml.ToString();
                         }
                     }
                     */
                    /*Getting Export Data*/
                    conn.Open();
                    var reader = command.ExecuteReader();
                    int ColumnCount = reader.FieldCount;

                    while (reader.Read())
                    {
                        for (int ColumnNumber = 0; ColumnNumber < ColumnCount; ColumnNumber++)
                        {
                            if (reader.GetString(ColumnNumber) != "")
                            {
                                jsonString = jsonString + "," + reader.GetString(ColumnNumber);
                            }
                        }
                    }
                    if (jsonString == "")
                    {
                        return null;
                    }
                    jsonString = "[" + jsonString.Substring(1) + "]";
                    var jsonDefinition = new object[] { };
                    var result = JsonConvert.DeserializeAnonymousType(jsonString, jsonDefinition);

                    foreach (dynamic obj in result)
                    {
                        foreach (JProperty property in obj.Properties())
                        {
                            jsonKey = jsonKey + "," + property.Name;
                            jsonVal = jsonVal + "," + property.Value;
                        }
                        header = jsonKey;
                        contentList.Add(jsonVal.Substring(1));
                        jsonVal = "";
                        jsonKey = "";
                    }
                    sw.WriteLine(header.Substring(1));
                    foreach (object content in contentList)
                    {
                        sw.WriteLine(content);
                    }

                    using (StreamWriter writer = new StreamWriter(FilePath))
                    {
                        writer.WriteLine(sw);
                    }
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", param.document_template + ".csv"));
                    HttpContext.Current.Response.ContentType = "text/csv";
                    HttpContext.Current.Response.Write(FilePath);
                    HttpContext.Current.Response.End();
                    return null;

                    /*HttpResponseMessage httpResponseMessage = new HttpResponseMessage(HttpStatusCode.OK);

                    httpResponseMessage.Content = new StringContent(sw.ToString());
                    httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/csv");
                    httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment"); //attachment will force download
                    httpResponseMessage.Content.Headers.ContentDisposition.FileName = param.document_template + ".csv";

                    return httpResponseMessage;*/

                }
            }
        }

        [HttpGet]
        [Route("api/export1")]
        public HttpResponseMessage Export()
        {

            string ConnectionString, header, jsonKey, jsonVal, jsonString;
            string data_retrieve_service_name, locale_id, country_code, document_template, client_id, user_id;
            XmlDocument xDoc;

            ConnectionString = null;
            header = null;
            jsonKey = null;
            jsonVal = null;
            jsonString = "";
            data_retrieve_service_name = "sp_retrieve_manage_asset_master_list";
            locale_id = "en-us";
            country_code = "in";
            document_template = "manage_asset_master";
            client_id = "cp";
            user_id = "Nisha";

            string FilePath = @"E:/Export/manage_asset_master.csv";

            xDoc = new XmlDocument();
            var contentList = new List<string>();
            StringWriter sw = new StringWriter();
            StringBuilder sb = new StringBuilder();

            ConnectionString = @"Data Source = peg-5\sqlexpress ; User Id = sa; Password = sa@123 ; Initial Catalog = msv_export; Integrated Security = True";
            // xDoc.LoadXml(data_retrieve_request_xml);

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    command.CommandText = data_retrieve_service_name;
                    // command.Parameters.Add("@i_session_id", SqlDbType.UniqueIdentifier).Value = new Guid(session_id);
                    command.Parameters.Add("@i_user_id", SqlDbType.NVarChar, 12).Value = user_id;
                    command.Parameters.Add("@i_client_id", SqlDbType.VarChar, 20).Value = client_id;
                    command.Parameters.Add("@i_locale_id", SqlDbType.VarChar, 5).Value = locale_id;
                    command.Parameters.Add("@i_country_code", SqlDbType.VarChar, 3).Value = country_code;

                    /* FORMING THE DYNAMIC SQL PARAMETERS */
                    /* foreach (XmlNode childNode in xDoc.SelectSingleNode("signature").ChildNodes)
                     {
                         if (childNode.Name.IndexOf("o_") == 0)
                         {
                             command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 5).Direction = ParameterDirection.Output;
                         }
                         else
                         {
                             command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 2500).Value = childNode.InnerXml.ToString();
                         }
                     }*/

                    /*Getting Export Data*/
                    conn.Open();
                    var reader = command.ExecuteReader();
                    int ColumnCount = reader.FieldCount;

                    while (reader.Read())
                    {
                        for (int ColumnNumber = 0; ColumnNumber < ColumnCount; ColumnNumber++)
                        {
                            if (reader.GetString(ColumnNumber) != "")
                            {
                                jsonString = jsonString + "," + reader.GetString(ColumnNumber);
                            }
                        }
                    }
                    if (jsonString == "")
                    {
                        return null;
                    }
                    jsonString = "[" + jsonString.Substring(1) + "]";
                    var jsonDefinition = new object[] { };
                    var result = JsonConvert.DeserializeAnonymousType(jsonString, jsonDefinition);

                    foreach (dynamic obj in result)
                    {
                        foreach (JProperty property in obj.Properties())
                        {
                            jsonKey = jsonKey + "," + property.Name;
                            jsonVal = jsonVal + "," + property.Value;
                        }
                        header = jsonKey;
                        contentList.Add(jsonVal.Substring(1));
                        jsonVal = "";
                        jsonKey = "";
                    }
                    sw.WriteLine(header.Substring(1));
                    foreach (object content in contentList)
                    {
                        sw.WriteLine(content);
                    }
                    
                    using (StreamWriter writer = new StreamWriter(FilePath))
                    {
                        writer.WriteLine(sw);
                    }
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", document_template + ".csv"));
                    HttpContext.Current.Response.ContentType = "text/csv";
                    HttpContext.Current.Response.WriteFile(FilePath);
                    HttpContext.Current.Response.End();
                    return null;


                   /*HttpResponseMessage httpResponseMessage = new HttpResponseMessage(HttpStatusCode.OK);
                    httpResponseMessage.Content = FilePath;

                    httpResponseMessage.Content = new StringContent(sw.ToString());
                    httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/csv");
                    httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment"); //attachment will force download
                    httpResponseMessage.Content.Headers.ContentDisposition.FileName = document_template + ".csv";

//return File("~/Content/MyFile.pdf", "application/pdf", "MyRenamedFile.pdf");
                    //return File(httpResponseMessage);

                    return httpResponseMessage;*/

                }
            }
        }

        [HttpGet]
        [Route("api/DownloadExcel")]
        public HttpResponseMessage DownloadExcel(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", Path.GetFileName(filePath) + ".csv"));
                    HttpContext.Current.Response.ContentType = "text/csv";
                    HttpContext.Current.Response.Write("Ouput FilePath :" + filePath);
                    HttpContext.Current.Response.End();
                }
                return null;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
