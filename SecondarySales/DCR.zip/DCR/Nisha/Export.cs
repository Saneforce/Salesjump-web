using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;
using System.Xml;


namespace JsonExport.Controllers
{

    public class Export_Parameter
    {
        public string session_id { get; set; }
        public string user_id { get; set; }
        public string client_id { get; set; }
        public string locale_id { get; set; }
        public string country_code { get; set; }
        public string report_code { get; set; }
        public string document_type { get; set; }
        public string document_template { get; set; }
        public string data_retrieve_service_name { get; set; }
        public string data_retrieve_request_xml { get; set; }

    }
    public class ExportController : ApiController
    {
        [HttpGet]
        [Route("api/DownloadExcel")]
        public HttpResponseMessage DownloadExcel(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", Path.GetFileName(filePath) + ".csv"));
                    HttpContext.Current.Response.ContentType = "text/csv";
                    HttpContext.Current.Response.WriteFile(filePath);
                    HttpContext.Current.Response.End();
                }
                return null;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("api/exportpost")]
        public HttpResponseMessage Export12([FromBody] Export_Parameter param)
        {
            string ConnectionString, header, jsonKey, jsonVal, jsonString, FilePath;
            XmlDocument xDoc;

            ConnectionString = null;
            header = null;
            jsonKey = null;
            jsonVal = null;
            jsonString = "";
            char[] delimiter = new char[] { '|' };
            FilePath = AppDomain.CurrentDomain.BaseDirectory + "content_store" + "/" + param.client_id + "/" + param.country_code + "/" + "Export" + "/" + param.document_template + "_" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".csv";

            xDoc = new XmlDocument();
            var contentList = new List<string>();
            StringWriter sw = new StringWriter();
            StringBuilder sb = new StringBuilder();

            ConnectionString = WebConfigurationManager.ConnectionStrings["conn_" + param.client_id + "app"].ConnectionString;
            xDoc.LoadXml(param.data_retrieve_request_xml);


            //ConnectionString = ConfigurationManager.ConnectionStrings["conn_" + param.client_id + "app"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    command.CommandText = param.data_retrieve_service_name;
                    command.Parameters.Add("@i_session_id", SqlDbType.UniqueIdentifier).Value = new Guid(param.session_id);
                    command.Parameters.Add("@i_user_id", SqlDbType.NVarChar, 12).Value = param.user_id;
                    command.Parameters.Add("@i_client_id", SqlDbType.VarChar, 20).Value = param.client_id;
                    command.Parameters.Add("@i_locale_id", SqlDbType.VarChar, 5).Value = param.locale_id;
                    command.Parameters.Add("@i_country_code", SqlDbType.VarChar, 3).Value = param.country_code;
                    command.Parameters.Add("@i_report_code", SqlDbType.VarChar, 100).Value = param.report_code;
                    command.Parameters.Add("@o_retrieve_status", SqlDbType.VarChar, 5).Value = ParameterDirection.Output;
                    command.Parameters.Add("@i_inputparam_xml", SqlDbType.NVarChar, 2500).Value = xDoc.InnerXml.ToString();

                    /* FORMING THE DYNAMIC SQL PARAMETERS */
                    /* foreach (XmlNode childNode in xDoc.SelectSingleNode("signature").ChildNodes)
                     {
                         if (childNode.Name.IndexOf("o_") == 0)
                         {
                             command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 5).Direction = ParameterDirection.Output;
                         }
                         else
                         {
                             command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 2500).Value = childNode.InnerXml.ToString();
                         }
                     }*/


                    /*Getting Export Data*/
                    conn.Open();
                    var reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        if (reader.GetString(1) != "")
                        {
                            jsonString = "[" + reader.GetString(1) + "]";
                            var jsonDefinition = new object[] { };
                            var result = JsonConvert.DeserializeAnonymousType(jsonString, jsonDefinition);
                            foreach (dynamic obj in result)
                            {
                                foreach (JProperty property in obj.Properties())
                                {
                                    jsonKey =  jsonKey + "," + property.Name;
                                    jsonVal = jsonVal + ",(" + property.Value + ")";
                                }

                                header = jsonKey;
                                contentList.Add(jsonVal.Substring(1));
                                jsonVal = "";
                                jsonKey = "";

                            }
                        }
                    }
         
                    sw.WriteLine((header.Substring(1)));
                    foreach (object content in contentList)
                    {
                        sw.WriteLine(content);

                    }
                    if (File.Exists(FilePath))
                    {
                        File.Delete(FilePath);
                    }
                    using (StreamWriter writer = new StreamWriter(FilePath))
                    {
                        writer.WriteLine(sw);
                    }
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", param.document_template + ".csv"));
                    //  HttpContext.Current.Response.ContentType = "text/csv";
                    HttpContext.Current.Response.ContentType = "application/octet-stream";
                    HttpContext.Current.Response.Write(FilePath);
                    HttpContext.Current.Response.End();
                    return null;

                }
            }

        }

    }
}
