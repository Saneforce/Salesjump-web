﻿using Bytescout.Spreadsheet;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;
using System.Xml;
using msvInterface;
using UmoldITLibraries;
using CustomLibraries;
using System.Collections.Generic;

namespace GenerateExport.Controllers
{
    public class Export_Parameter
    {
        public string session_id { get; set; }
        public string user_id { get; set; }
        public string client_id { get; set; }
        public string locale_id { get; set; }
        public string country_code { get; set; }
        public string document_type { get; set; }
        public string document_template { get; set; }
        public string data_retrieve_service_name { get; set; }
        public string data_retrieve_request_xml { get; set; }
        public string document_file_name { get; set; }
    }

    public class ExportController : ApiController
    {

        private static String outputFilePath, outputFileName;
        private static String[] columnIdList, columnNameList, columnTemplateList, columnFormatList;

        [HttpGet]
        [Route("api/DownloadExportFile")]
        public HttpResponseMessage DownloadExcel(string filePath, string client_id, string country_code)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", Path.GetFileName(filePath)));
                    HttpContext.Current.Response.ContentType = "application/octet-stream";
                    HttpContext.Current.Response.WriteFile(filePath);
                    HttpContext.Current.Response.End();
                }
                return null;
            }
            catch (Exception ex)
            {
                msvUtil.LogException(AppDomain.CurrentDomain.BaseDirectory, client_id, country_code, "Export", ex.Message, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.OK, "Download File Error");
            }
        }

        [HttpPost]
        [Route("api/generate_export_file")]
        public HttpResponseMessage Export([FromBody] Export_Parameter param)
        {
            string connectionString, fmtString;
            outputFilePath = "";
            outputFileName = "";

            XmlDocument xDoc;
            SqlDataAdapter dataAdapter;
            DataTable dataTable;
            SqlConnection conn;
            SqlCommand command;
            Dictionary<object, object> contextDataItems = null;

            connectionString = null;
            fmtString = "";
            dataTable = new DataTable();
            xDoc = new XmlDocument();
            conn = new SqlConnection();
            command = new SqlCommand();
            contextDataItems = new Dictionary<object, object>();
             
            contextDataItems.Add("sessionId",param.session_id);
            contextDataItems.Add("userId", param.user_id);
            contextDataItems.Add("client_id", param.client_id);
            contextDataItems.Add("country_code", param.country_code);
            contextDataItems.Add("locale_id", param.locale_id);

            connectionString = CustomLibraries.CustomUtil.getConnectionString(contextDataItems,"","");
            //connectionString = WebConfigurationManager.ConnectionStrings["conn_" + param.client_id  +"_" + param.country_code + "_app"].ConnectionString;
            try
            {
                xDoc.LoadXml(param.data_retrieve_request_xml);

                fmtString = GetFormatContent(param.document_template, param.client_id, param.country_code, param.locale_id);

                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = param.data_retrieve_service_name;
                command.Parameters.Add("@i_session_id", SqlDbType.UniqueIdentifier).Value = new Guid(param.session_id);
                command.Parameters.Add("@i_user_id", SqlDbType.NVarChar, 12).Value = param.user_id;
                command.Parameters.Add("@i_client_id", SqlDbType.VarChar, 20).Value = param.client_id;
                command.Parameters.Add("@i_locale_id", SqlDbType.VarChar, 5).Value = param.locale_id;
                command.Parameters.Add("@i_country_code", SqlDbType.VarChar, 3).Value = param.country_code;


                /* FORMING THE DYNAMIC SQL PARAMETERS */
                foreach (XmlNode childNode in xDoc.SelectSingleNode("signature").ChildNodes)
                {
                    if (childNode.Name.IndexOf("o_") == 0)
                    {
                        command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 5).Direction = ParameterDirection.Output;
                    }
                    else
                    {
                        command.Parameters.Add("@" + childNode.Name, SqlDbType.NVarChar, 2500).Value = childNode.InnerXml.ToString();
                    }
                }

                /*Getting Export Data*/
                conn.Open();
                dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                dataAdapter.Dispose();

                if (param.document_file_name != null)
                {
                    outputFileName = param.document_file_name;
                }
                outputFilePath = CreateExport(param.session_id, param.client_id, param.country_code, param.locale_id, dataTable, fmtString);

                if (outputFilePath != "")
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", Path.GetFileName(outputFilePath)));
                    HttpContext.Current.Response.ContentType = "application/octet-stream";
                    HttpContext.Current.Response.Write(outputFilePath);
                    HttpContext.Current.Response.End();
                }
                else
                {
                    throw new Exception();
                }
                return null;
            }
            catch (Exception ex)
            {
                msvUtil.LogException(AppDomain.CurrentDomain.BaseDirectory, param.client_id, param.country_code, "Export", ex.Message, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.OK, "");
            }

            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        public static String GetFormatContent(string templateName, string clientID, string countryCode, string localeID)
        {
            string fmtString = "";
            try
            {
                /* CHECK FOR FMT FILE IN THE GIVEN PATH*/
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_" + clientID + "_" + countryCode + "_" + localeID + "_fmt.json"))
                {
                    fmtString = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_" + clientID + "_" + countryCode + "_" + localeID + "_fmt.json");

                }
                else if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_" + clientID + "_" + countryCode + "_fmt.json"))
                {
                    fmtString = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_" + clientID + "_" + countryCode + "_fmt.json");

                }
                else if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_" + clientID + "_fmt.json"))
                {
                    fmtString = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_" + clientID + "_fmt.json");

                }
                else if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_fmt.json"))
                {
                    fmtString = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "fmt/export/" + templateName + "_fmt.json");

                }
                else
                {
                    throw new FileNotFoundException();
                }
                return fmtString;
            }
            catch (FileNotFoundException ex)
            {
                throw ex;
            }
        }


        public static String CreateExport(String sessionId, String clientID, String countryCode, String localeId, DataTable sourceTable, String fmtString)
        {
            DataTable fmtTable, exportTable, actualSourceTable;
            DataView exportView;

            int rowIndex = 0;
            try
            {
                if(fmtString != "")
                {
                    /* GET FORMAT INFORMATION */
                    var fmtObject = JsonConvert.DeserializeObject<dynamic>(fmtString);
                    fmtTable = JsonConvert.DeserializeObject<DataTable>((JsonConvert.SerializeObject(fmtObject.configuration)).Replace(@"\", @"\\"));

                    if (fmtObject.fileName != null)
                    {
                        outputFileName = (String)fmtObject.fileName;
                    }

                    if (outputFileName == "")
                    {
                        outputFileName = "Export Data";
                    }

                    /* Set outputfile path */
                    if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "content_store" + "\\" + clientID + "\\" + countryCode + "\\" + "Export"))
                    {
                        Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "content_store" + "\\" + clientID + "\\" + countryCode + "\\" + "Export");
                    }
                    outputFilePath = AppDomain.CurrentDomain.BaseDirectory + "content_store" + "\\" + clientID + "\\" + countryCode + "\\" + "Export" + "\\" + outputFileName + ".xlsx";

                    /* GET APPLICABLE COLUMN DETAILS */
                    columnIdList = fmtTable.AsEnumerable().Select(row => row.Field<String>("fieldId")).ToArray();
                    columnNameList = fmtTable.AsEnumerable().Select(row => row.Field<String>("fieldName")).ToArray();
                    columnTemplateList = fmtTable.AsEnumerable().Select(row => row.Field<String>("template")).ToArray();
                    columnFormatList = fmtTable.AsEnumerable().Select(row => row.Field<String>("format")).ToArray();

                    /* CONVERT SOURCE TABLE TO VALID DATA TABLE */
                    actualSourceTable = JsonConvert.DeserializeObject<DataTable>((@"[" + String.Join(",", sourceTable.AsEnumerable().Select(row => row.Field<String>(1)).ToArray()) + "]").Replace(@"\", @"\\"));

                    /* FILTER THE APPLICABLE COLUMNS FROM SOURCE TABLE */
                    exportView = new DataView(actualSourceTable);
                    exportTable = exportView.ToTable(false, columnIdList);
                    exportTable.TableName = outputFileName;

                    if (File.Exists(outputFilePath))
                    {
                        File.Delete(outputFilePath);
                    }
                    using (Spreadsheet spreadsheet = new Spreadsheet())
                    {
                        Worksheet worksheet = spreadsheet.Workbook.Worksheets.Add("Sheet1");

                        /* INSERT CONTENT INTO EXCEL */
                        spreadsheet.ImportFromDataTable(exportTable);

                        /* INSERT HEADER  INTO EXCEL */
                        worksheet.Rows.Insert(0);
                        for (int colIndex = 0; colIndex < exportTable.Columns.Count; colIndex++)
                        {
                            worksheet.Cell(0, colIndex).Value = fmtTable.Rows[rowIndex][0];
                            worksheet.Cell(0, colIndex).Font = new Font("Arial", 12, FontStyle.Bold);
                            worksheet.Columns[colIndex].Width = 150;
                            rowIndex++;
                        }
                        spreadsheet.SaveAs(outputFilePath);
                    }
                    if (File.Exists(outputFilePath))
                    {
                        Spreadsheet spreadsheet = new Spreadsheet();
                        spreadsheet.LoadFromFile(outputFilePath);
                        Worksheet worksheet1 = spreadsheet.Workbook.Worksheets.ByName("ByteScout Spreadsheet SDK");
                        worksheet1.Columns.Delete(0, 0);
                        spreadsheet.SaveAs(outputFilePath);
                        return outputFilePath;
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    throw new Exception();
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void Audit(String appRoot, String clientID, String countryCode, String component, String auditData)
        {
            String auditRoot, auditContent;

            try
            {
                auditRoot = appRoot + "\\" + "log" + "\\" + component + "\\" + "Audit";

                if (!Directory.Exists(auditRoot))
                {
                    Directory.CreateDirectory(auditRoot);
                }

                auditContent = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
                auditContent += Environment.NewLine;
                auditContent += "Error Message --> " + auditData;
                auditContent += Environment.NewLine;
                //auditContent += "Stack Trace --> " + stackTrace;
                auditContent += Environment.NewLine;
                auditContent += "**********************************************************************************************************************************";
                auditContent += Environment.NewLine;

                File.AppendAllText(auditRoot + "\\" + DateTime.Now.ToString("dd-MM-yyyy") + "-" + clientID + "-" + countryCode + ".txt", auditContent);
            }
            catch (Exception ex)
            {
                auditRoot = appRoot + "\\" + "log" + "\\" + "msvUtil" + "\\" + "Audit";

                if (!Directory.Exists(auditRoot))
                {
                    Directory.CreateDirectory(auditRoot);
                }

                auditContent = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
                auditContent += Environment.NewLine;
                auditContent += "Error Message --> " + ex.Message;
                auditContent += Environment.NewLine;
                auditContent += "Stack Trace --> " + ex.StackTrace;
                auditContent += Environment.NewLine;
                auditContent += "**********************************************************************************************************************************";
                auditContent += Environment.NewLine;

                File.AppendAllText(auditRoot + "\\" + DateTime.Now.ToString("dd-MM-yyyy") + ".txt", auditContent);
            }
        }
    }
}
