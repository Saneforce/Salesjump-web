﻿using HAPAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Filters;

namespace HAPAPI.Controllers
{
    public class TransVehicleController : ApiController
    {
        [HttpPost]
        [Route("api/insert_trans_vehicle")]
        [BasicAuthentication]
        public HttpResponseMessage TransVehicleInsert([FromBody] VehicleParameter param)
        {
            string connectionString;

            SqlConnection conn;
            SqlCommand command;

            conn = new SqlConnection();
            command = new SqlCommand();

            try
            {
                    connectionString = WebConfigurationManager.ConnectionStrings["Ereportcon"].ConnectionString;

                    conn.ConnectionString = connectionString;
                    command.Connection = conn;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    command.CommandText = "save_trans_vehicle_temprature";
                    command.Parameters.Add("@vehicle_no", SqlDbType.VarChar, 30).Value = param.vehicle_no;
                    command.Parameters.Add("@lat", SqlDbType.VarChar, 30).Value = param.lat;
                    command.Parameters.Add("@lng", SqlDbType.VarChar, 30).Value = param.lng;
                    command.Parameters.Add("@date_time", SqlDbType.DateTime).Value = param.date_time;
                    command.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = param.status;
                    command.Parameters.Add("@temp", SqlDbType.VarChar, 20).Value = param.temp;

                    conn.Open();
                    command.ExecuteNonQuery();
                    return Request.CreateResponse(HttpStatusCode.OK, "Data successfully inserted");                         
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message + ex.StackTrace);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
    }
    public class BasicAuthenticationAttribute : AuthorizationFilterAttribute
    {
        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            string authenticationString, originalString, username, password;
            if (actionContext.Request.Headers.Authorization == null)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
            }
            else
            {
                // Gets header parameters  
                 authenticationString = actionContext.Request.Headers.Authorization.Parameter;
                 originalString = Encoding.UTF8.GetString(Convert.FromBase64String(authenticationString));

                // Gets username and password  
                  username = originalString.Split(':')[0];
                  password = originalString.Split(':')[1];

                // Validate username and password  
                if (!VaidateUser(username, password))
                {
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
                }
            }

            base.OnAuthorization(actionContext);
        }
        public static bool VaidateUser(string username, string password)
        { 
            if (username == "adminhap" && password =="hap")  
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }    
}