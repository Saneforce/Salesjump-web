var json1 = {"name":"ramesh","age":"12"};

var json2 = {"member":"true"};

document.write(JSON.stringify($.extend(true,{},json1,json2)))
undefined
console.log(

document.write(JSON.stringify($.extend(true,{},json1,json2))))
VM521:1 undefined
undefined
var json1 = {"name":"ramesh","age":"12"};

undefined

var json2 = {"member":"true"};

undefined
json1
{name: "ramesh", age: "12"}
json2
{member: "true"}
(JSON.stringify($.extend(true,{},json1,json2)))
"{"name":"ramesh","age":"12","member":"true"}"
finaljson=json1.concat(json2);
VM644:1 Uncaught TypeError: json1.concat is not a function
    at <anonymous>:1:17
(anonymous) @ VM644:1
var jso1=["Chennai","Bangalore"];
undefined
var jso2=["TamilNadu","Karanataka"];
undefined
finaljson=jso1.concat(jso2);
(4) ["Chennai", "Bangalore", "TamilNadu", "Karanataka"]
var jsonObjectA = [{"name":"john"},{"age":"12"}];
undefined
var jsonObjectB = [{"sex":"male"},{"zip","23343"}];
VM676:1 Uncaught SyntaxError: Unexpected token ','
var jsonObjectB = [{"sex":"male"},{"zip","23343"}];
VM681:1 Uncaught SyntaxError: Unexpected token ','
var jsonObjectB = [{"sex":"male"},{"zip","23343"}];
VM685:1 Uncaught SyntaxError: Unexpected token ','
var jsonObjectB = [{"sex":"male"},{"Code":"12344"}];
undefined
jsonObjectA.concat(jsonObjectB);
(4) [{…}, {…}, {…}, {…}]0: {name: "john"}1: {age: "12"}2: {sex: "male"}3: {Code: "12344"}length: 4__proto__: Array(0)
var json11 =[ {"name":"john","age":"12"},{"name":"hn","age":"23"}];
undefined
var json21 =[ {"height":"1.2","weight":"11"},{"height":"22.2","weight":"56"}];
undefined
(JSON.stringify($.extend(false,{},json11,json21)))
"{"0":{"height":"1.2","weight":"11"},"1":{"height":"22.2","weight":"56"}}"
json11
(2) [{…}, {…}]0: {name: "john", age: "12"}1: {name: "hn", age: "23"}length: 2__proto__: Array(0)
json21
(2) [{…}, {…}]0: {height: "1.2", weight: "11"}1: {height: "22.2", weight: "56"}length: 2__proto__: Array(0)
$.extend(false,{},json11,json21)
{0: {…}, 1: {…}}0: {height: "1.2", weight: "11"}1: {height: "22.2", weight: "56"}__proto__: Object