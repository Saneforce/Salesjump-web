<%@ Page Language="C#" MasterPageFile="~/Master.master" AutoEventWireup="true" CodeFile="DCR_Analysiss.aspx.cs" Inherits="MasterFiles_DCR_Analysiss" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <link type="text/css" href="../css/SalesForce_New/bootstrap-select.min.css" rel="stylesheet" />
    <link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel = "stylesheet">
    <style>
        .tab {
            float: left;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
            width: 25%;
            height: 475px;
        }

        .tab1 {
            float: right;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
            width: 75%;
            height: 475px;
        }

        .dropdown-menu {
           /* height: 300px;*/
            overflow: auto;
            max-height: 210px;
        }

        #sortable1 {
            list-style-type: none;
            margin: 0;
            padding: 0;
            width: 100%;
        }
        #sortable1 li {
            margin: 0 3px 3px 3px;
            padding: 0.4em;
            padding-left: 1.5em;
            font-size: 0.9em;
            height: 35px;
        }

        #sortable1 li span {
            position: absolute;
            margin-left: -1.3em;
        }
        table {
          border: 1px solid #666;
          width: 100%;
          text-align: left;
        }
        
        th {
          background: #f8f8f8;
          font-weight: bold;
          padding: 2px;
        }
    </style>
    <form runat="server" id="frm1">
        <div class="row">
            <div class="col-lg-12 sub-header">
                DCR Analysis              
            </div>
            <div class="tab">
                <button type="button" style="background-color: #1a73e8; float: right;padding-left:5px;" class="btnTemp btn-primary">Add New</button>
                <div class="row hiderow" id="Ftablerow" style="margin-bottom: 1rem!important;display:none">
                     <div class="col-xs-12 col-sm-12">
                         <div class="col-xs-12 col-sm-12">
                             <label style="padding-top: 5px;color:#3c8dbc;padding-left: 20px;">AddTemplateName</label>
                             <input class='tgl tgl-skewed' id="txtName" type='textbox'  /> 
                         </div>
                        <div class="col-xs-12 col-sm-10">       
                           <!--<ul class="dropdown-menu1 dropdown-custom dropdown-menu-right">
                            <li class="dropdowntemp user user-menu">-->
                            	<a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            		<span><span id="label1">+ TemplateList</span><i class="caret"></i></span>
                            	</a>
                                 <ul class="dropdown-menu dropdown-custom dropdown-menu-right" id ="sortable1">                                                                                 
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         <input class='tgl tgl-skewed' id="Sf_Name" type='checkbox' value="Sf_Name" />
                                         <label class='tgl' for="Sf_Name" style="height: 1px;">Fieldforce Name</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         <input class='tgl tgl-skewed' id="Sf_Joining_Date" type='checkbox' value="Sf_Joining_Date" />
                                         <label class='tgl' for="Sf_Joining_Date" style="height: 1px;">Joining Date</label>
                                     </li>                                                                                 
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Designation" type='checkbox' value="Designation" />
                                     	<label class='tgl'  for="Designation" style="height: 1px;"> Designation</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="dt" type='checkbox' value="dt" />
                                     	<label class='tgl'for="dt" style="height: 1px;"> Date</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Wtype" type='checkbox' value="Wtype" />
                                     	<label class='tgl-btn'for="Wtype" style="height: 1px;"> Worktype</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="ClstrName" type='checkbox' value="ClstrName" />
                                     	<label class='tgl-btn'for="ClstrName" style="height: 1px;"> Route Worked</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Reporting_Sf" type='checkbox' value="Reporting_Sf" />
                                     	<label class='tgl-btn'for="Reporting_Sf" style="height: 1px;"> Reporting Manager 1</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Reporting" type='checkbox' value="Reporting" />
                                     	<label class='tgl-btn'for="Reporting" style="height: 1px;"> Reporting Manager 2</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Route" type='checkbox' value="Route" />
                                     	<label class='tgl-btn'for="Route" style="height: 1px;"> Route as per Tour Plan</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="remarks" type='checkbox' value="remarks" />
                                     	<label class='tgl-btn'for="remarks" style="height: 1px;"> Daywise Remark</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Cust_Name" type='checkbox' value="Cust_Name" />
                                     	<label class='tgl-btn'for="Cust_Name" style="height: 1px;"> Customer Name</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Cust_Addr" type='checkbox' value="Cust_Addr" />
                                     	<label class='tgl-btn'for="Cust_Addr" style="height: 1px;"> Address</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Session" type='checkbox' value="Session" />
                                     	<label class='tgl-btn'for="Session" style="height: 1px;"> Session</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Cust_Code" type='checkbox' value="Cust_Code" />
                                     	<label class='tgl-btn'for="Cust_Code" style="height: 1px;"> Retailer Code</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Cust_Spec" type='checkbox' value="Cust_Spec" />
                                     	<label class='tgl-btn'for="Cust_Spec" style="height: 1px;"> Retailer Channel</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Cust_Cls" type='checkbox' value="Cust_Cls" />
                                     	<label class='tgl-btn'for="Cust_Cls" style="height: 1px;"> Retailer Class</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Activity_Date" type='checkbox' value="Activity_Date" />
                                     	<label class='tgl-btn'for="Activity_Date" style="height: 1px;">Visit Date & Time</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="POB_Value" type='checkbox' value="POB_Value" />
                                     	<label class='tgl-btn'for="POB_Value" style="height: 1px;"> Order Value</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="OrderTyp" type='checkbox' value="OrderTyp" />
                                     	<label class='tgl-btn'for="OrderTyp" style="height: 1px;"> Order Type</label>
                                     </li>                                    
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Product" type='checkbox' value="Product" />
                                     	<label class='tgl-btn'for="Product" style="height: 1px;"> Product</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Quantity" type='checkbox' value="Quantity" />
                                     	<label class='tgl-btn'for="Quantity" style="height: 1px;"> Product Quantity</label>
                                     </li>
                                     <li class="ui-state-default"style="display:none"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Prod_SKU" type='checkbox' value="Prod_SKU" style="display:none"/>
                                     	<label class='tgl-btn'for="Prod_SKU" style="height: 1px;"> Product SKU</label>
                                     </li>
                                     <li class="ui-state-default" style="display:none"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Prod_Value" type='checkbox' value="Prod_Value" style="display:none"/>
                                     	<label class='tgl-btn'for="Prod_Value" style="height: 1px;"> Product Value</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="net_weight_value" type='checkbox' value="net_weight_value" />
                                     	<label class='tgl-btn'for="net_weight_value" style="height: 1px;"> Nett Weight</label>
                                     </li>
                                     <li class="ui-state-default" style="display:none"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Att_Status" type='checkbox' value="Att_Status" />
                                     	<label class='tgl-btn'for="Att_Status" style="height: 1px;"> Attendance Status</label>
                                     </li>
                                     <li class="ui-state-default" style="display:none"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Sub_time" type='checkbox' value="Sub_time" />
                                     	<label class='tgl-btn'for="Sub_time" style="height: 1px;">Day Plan Submission Time</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="stockist_name" type='checkbox' value="stockist_name" />
                                     	<label class='tgl-btn'for="stockist_name" style="height: 1px;"> Distributor Name</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="filters" type='checkbox' value="filters" />
                                     	<label class='tgl-btn'for="filters" style="height: 1px;"> Visited Outlets for day</label>
                                     </li>
                                     <li class="ui-state-default" style="display:none"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Prod_Catgry" type='checkbox' value="PProd_Catgry" />
                                     	<label class='tgl-btn'for="Prod_Catgry" style="height: 1px;"> Product Category</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="latlong" type='checkbox' value="latlong" />
                                     	<label class='tgl-btn'for="latlong" style="height: 1px;"> Lat & Long</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Activity_Remarks" type='checkbox' value="Activity_Remarks" />
                                     	<label class='tgl-btn'for="Activity_Remarks" style="height: 1px;"> Remark</label>
                                     </li>
                                     <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                     	<input class='tgl tgl-skewed' id="Imgurl" type='checkbox' value="Imgurl" />
                                     	<label class='tgl-btn'for="Imgurl" style="height: 1px;"> Event Capture</label>
                                     </li>
                                     <li>
                                        <button type="button" class="btn btn-secondary"  id="closefields1">Cancel</button>
                                        <button type="button" style="background-color: #1a73e8;" class="btn btn-primary"  id="svfields1">Apply</button>
                                    </li>
                                 </ul>                                    
                            <!-- </li>
                        </ul>-->
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-10">
                        <div class="col-xs-12 col-sm-10">
                            <label style="padding-top: 5px;">Template setting</label>
                        </div>
                        <div class="col-xs-12 col-sm-12" style="padding-left: 0px;">
                            <div class="col-xs-12 col-sm-12">
                                <select id="mtemp" style="padding-right:115px;">
                                    <option value="select">--select--</option>
                                </select>
                            </div>                            
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-10">
                        <div class="col-xs-12 col-sm-10">
                            <label style="padding-top: 5px;">Fieldforce Name</label>
                        </div>
                        <select id="mforms" multiple data-actions-box="true" style="padding-left: 0px;">
                        </select>
                    </div>
                    <div class="row hiderow" id="Ftablerow1" style="margin-bottom: 1rem!important;">
                    <div class="col-xs-12 col-sm-12">
                        <div class="col-xs-12 col-sm-7">
                            <div class="col-xs-12 col-sm-10">
                                <label style="padding-top: 5px;">Date Selection </label>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-10">
                            <div class="col-xs-12 col-sm-12">
                                <span style="float: left; margin-right: 15px;">
                                    <div id="reportrange" class="form-control mt-5 mb-5" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc;">
                                        <i class="fa fa-calendar"></i>&nbsp;
                                        <span id="ordDate"></span>
                                        <i class="fa fa-caret-down"></i>
                                    </div>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>                
                <div>
                    <div class="col-xs-12 col-sm-10">
                        <div class="col-xs-12 col-sm-5">
                            <button type="button" style="background-color: #1a73e8; float: right;" class="btn btn-primary" id="viewfields">View</button>
                        </div>
                        <div class="col-xs-12 col-sm-5">
                            <button type="button" class="btn btn-primary" style="background-color: #1a73e8; float: right;" id="clearfields">Clear</button>
                        </div>
                    </div>
                </div>
            </div>                
            <div class="tab1" style="float: center;overflow-y:scroll;overflow-x:scroll;">
                <div class="tableclass" >
                    <table class="table table-hover" id="OrderList" style="font-size:12px;display:none">
                    	<thead class="text-warning">
                    	</thead>
                    	<tbody>
                    	</tbody>
                    </table>
                </div>
            </div>
        </div>
    </form>
    <script type="text/javascript">              
        var MasFrms = [], dropdownval = '', rowkey = [], fnamematch = [], tempName = [], tempList = [], listobj = [], sfCodematch = [], rowtempl = [];
        var DCR_Products = [], DCR_ProdDts = [], DCR_OrderDts = [], DCR_EventCap = [], DCR_FForce = [], DCR_Dayplan = [], DCR_Customer = [], DCR_tourplan = [];
        var templatelist = '', templateName = '', fdt = '', tdt ='', selectsfcode = '';
        function loadSfDetails() {
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/getForms",
                data: "{'divcode':'<%=Session["div_code"]%>','sfcode':'<%=Session["Sf_Code"]%>'}",
                dataType: "json",
                success: function (data) {
                    MasFrms = JSON.parse(data.d) || [];
                    var fillfrms = MasFrms;
                    $('#mforms').empty();

                    for ($i = 0; $i < fillfrms.length; $i++) {
                        if(fillfrms[$i].Sf_Code != 'admin')
                        $('#mforms').append('<option value="' + fillfrms[$i].Sf_Code + '">' + fillfrms[$i].Sf_Name + '</option>');
                    }

                },
                error: function (result) {
                    alert(JSON.stringify(result));
                }
            });
            $('#mforms').selectpicker({
                liveSearch: true
            });
            $('#mforms').addClass('col-xs-12').selectpicker('setStyle');
        }

        $(document).ready(function () {
            loadSfDetails();
            retrieveTemplateList();
        });

        $('#closefields').on('click', function () {
            clearFields();
        }); 
        $('#svfields1').on('click', function () {
            templateName = $('#txtName').val();
            if (templateName == '')
                alert("Please Give Template Name");
            else {
                $('.tgl').each(function () {
                if ($(this).prop("checked") == true)
                    templatelist +=  '"'+ $(this).val() + '":"' +  $(this).next('label').text()+ '",';
                });
                templatelist = '{' + templatelist.substring(0, templatelist.length - 1) + '}';
            }
            alert(templatelist);
            saveTemplateList(templateName, templatelist);
            
        });
        $('.btnTemp').on('click', function () {
            $('#Ftablerow').show();
        });
        $('#closefields1').on('click', function () {
            clearFields();
        });

        $('#mtemp').on('change', function () {
            //showTabledata();            
        })

        $('#clearfields').on('click', function () {
            clearFields();
            alert('fields cleared');
        })
        $('#viewfields').on('click', function () {
            getViewFields();
        })
        
        var tempData = [];
        function retrieveTemplateList() {
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/getTemplate",
                data: "{'divcode':'<%=Session["div_code"]%>'}",
                dataType: "json",
                success: function (data) {
                    $('#mtemp').empty().append('<option value=select>--select--</option>');
                    tempData = JSON.parse(data.d) || [];
                    for (var i = 0; i < tempData.length; i++) {
                        //tempData[i].template_list
                        $('#mtemp').append('<option value="' + i + '">' + tempData[i].template_name + '</option>');
                    }                                                           
                },
                error: function (result) {
                    alert(JSON.stringify(result));
                }
            });
        }
        function saveTemplateList(templateName, templatelist) {
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/savetemplate",
                data: "{'divcode':'<%=Session["div_code"]%>','tpname':'" + templateName + "','tplist':'" + templatelist + "'}",
                dataType: "json",
                success: function (data) {
                   alert("success");
                    $('#Ftablerow').hide();
                },
                error: function (result) {
                    alert(JSON.stringify(result));
                }
            });
            clearFields();
            retrieveTemplateList();
        }

        function getViewFields() {
            var id = '';
            var id = $('#ordDate').text();
            selectsfcode = '';
            sfCodematch = [];
            $('#mforms :selected').each(function () {
                selectsfcode += $(this).val() + ',';
                sfCodematch.push($(this).val());
            });
            //selectsfcode = selectsfcode.trim();
            alert(selectsfcode);

            id = id.split('-');
            fdt = id[2].trim() + '-' + id[1] + '-' + id[0];
            tdt = id[5] + '-' + id[4] + '-' + id[3].trim();
            loadData();
           
            showTabledata();
            $('#OrderList').show();
        }

        function joinObjects(ar1, ar2, keys1, keys2) {
            result=[]
            for (il = 0; il < ar1.length; il++) {
                jArr = ar2.filter(function (a) {
                    iflg = 0; k = ar1[il];
                    for (ij = 0; ij < keys1.length; ij++) {
                        if (a[keys1[ij]] != [keys1[ij]]) iflg = 1;
                    }
                    return (iflg == 0);
                });
                if(jArr.length < 1) {
                    ritem = {}
                    ritem = JSON.parse(JSON.stringify(ar1[il]));
                    result.push(ritem);
                }
                else {
                    for (ij = 0; ij < jArr.length; ij++) {
                        ritem = {}
                        ritem = JSON.parse(JSON.stringify(ar1[il]));
                        for (var key in jArr[ij]) {
                            ritem[key] = jArr[key];
                        }
                        result.push(ritem);
                    }
                }
            }
            return result;
        }

        function showTabledata() {
            /*var head = $("<tr />");
            var indx = $('#mtemp :selected').val();
            
            $("#OrderList thead").html("");
            $("#OrderList tbody").html("");	
            listobj = JSON.parse(tempData[indx].template_list) || [];
            for (var key in listobj) {
                head.append($("<th>" + listobj[key] + "</th>"));
                $("#OrderList thead").append(head);
            }
            tablebind();  */
            var head = $("<tr />");
            var indx = $('#mtemp :selected').val();
            
            $("#OrderList thead").html("");
            $("#OrderList tbody").html("");	
            listobj = JSON.parse(tempData[indx].template_list) || [];
            for (var key in listobj) {
                if (key != 'Product') {
                    head.append($("<th rowspan=3>" + listobj[key] + "</th>"));
                    $("#OrderList thead").append(head);
                }
                else {
                    //head.append($("<th colspan=9>" + listobj[key] + "</th>"));
                    head.append($("<tr><td></td><td></td><td></td><td></td><th colspan=9>"+ listobj[key] +"</th></tr><tr><td><th colspan=3>Product1</th></td><td><th colspan=3>Product2</th></td><td><th colspan=3>Product3</th><td></td></tr><tr><td><th>Quantity</th><th>Value</th><th>SKU</th></td><td><th>Quantity</th><th>Value</th><th>SKU</th></td><td><th>Quantity</th><th>Value</th><th>SKU</th></td></tr>"));
                    $("#OrderList thead").append(head);
                }
                
                
            }
            tablebind();
        }
        ResultArr = [];
        rwStr = "";
        Sesion = ""; actdate = ""; pobVal = ""; netwtVal = ""; stkName = ""; latlg = ""; actRmk = ""; ordTyp = ""; custCd = "";
                    custName = ""; custAddr = ""; custSpec = ""; custCls = ""; mycust = [];
                    prdQnty = ""; visitout = "";

        function tablebind() {
            console.log(joinObjects(DCR_FForce, DCR_Dayplan, ["sf_code"], ["sf_code"]));

            for (var j = 0; j < DCR_FForce.length; j++) {
                

                dt = new Date(fdt);
                edt = new Date(tdt);
                
                while (dt <= edt) {
                    ritem = {}
                    ritem = JSON.parse(JSON.stringify(DCR_FForce[j]));

                   ritem["dt"] = (dt.getDate() < 10 ? "0" : "") + dt.getDate() + "/" + ((dt.getMonth() + 1) < 10 ? "0" : "") + (dt.getMonth() + 1) + "/" + dt.getFullYear();
                    
                   mypln = DCR_Dayplan.filter(function (a) {
                        mdt = new Date(a.dt);
                        return (a.sf_code == DCR_FForce[j].Sf_Code &&
                            (((mdt.getDate() < 10 ? "0" : "") + mdt.getDate() + "/" + ((mdt.getMonth() + 1) < 10 ? "0" : "") + (mdt.getMonth() + 1) + "/" + mdt.getFullYear())
                                == ((dt.getDate() < 10 ? "0" : "") + dt.getDate() + "/" + ((dt.getMonth() + 1) < 10 ? "0" : "") + (dt.getMonth() + 1) + "/" + dt.getFullYear())));
                    })
                    wTyp = ""; wRut = ""; rmks = "";
                    for (l = 0; l < mypln.length; l++) {
                        if (l > 0) {
                            wTyp += ", ";
                            wRut += ", ";
                            rmks += ", ";
                        }
                        wTyp += mypln[l]["Wtype"];
                        wRut += mypln[l]["ClstrName"];
                        rmks += mypln[l]["remarks"];
                        
                    }

                    mytur = DCR_tourplan.filter(function (a) {
                        mtdt = new Date(a.dt);
                        return (a.sf_code == DCR_FForce[j].Sf_Code &&
                            (((mtdt.getDate() < 10 ? "0" : "") + mtdt.getDate() + "/" + ((mtdt.getMonth() + 1) < 10 ? "0" : "") + (mtdt.getMonth() + 1) + "/" + mtdt.getFullYear())
                                == ((dt.getDate() < 10 ? "0" : "") + dt.getDate() + "/" + ((dt.getMonth() + 1) < 10 ? "0" : "") + (dt.getMonth() + 1) + "/" + dt.getFullYear())));
                    })
                    Root = ""; 
                    for (k = 0; k < mytur.length; k++) {
                        if (k > 0) {
                            Root += ", ";
                        }
                        Root += mytur[k]["Route"];
                    }







                    myodr = DCR_OrderDts.filter(function (a) {
                        modt = new Date(a.dt);
                        return (a.sf_code == DCR_FForce[j].Sf_Code &&
                            (((modt.getDate() < 10 ? "0" : "") + modt.getDate() + "/" + ((modt.getMonth() + 1) < 10 ? "0" : "") + (modt.getMonth() + 1) + "/" + modt.getFullYear())
                                == ((dt.getDate() < 10 ? "0" : "") + dt.getDate() + "/" + ((dt.getMonth() + 1) < 10 ? "0" : "") + (dt.getMonth() + 1) + "/" + dt.getFullYear())));
                    })
                    
                    for (m = 0; m < myodr.length; m++) {
                        if (m > 0) {
                            Sesion = ", ";
                            actdate = ", ";
                            pobVal = ", ";
                            netwtVal = ", ";
                            stkName = ", ";
                            latlg = ", ";
                            actRmk = ", ";
                            ordTyp = ", ";
                            custCd += ", ";
                        }
                        Sesion += myodr[m]["Session"];
                        actdate += myodr[m]["Activity_Date"];
                        pobVal += myodr[m]["POB_Value"];
                        netwtVal += myodr[m]["net_weight_value"];
                        stkName += myodr[m]["stockist_name"];
                        latlg += myodr[m]["latlong"];
                        actRmk += myodr[m]["Activity_Remarks"];
                        ordTyp += myodr[m]["OrderTyp"];
                        custCd += myodr[m]["Cust_Code"];

                        
                    }

                    mycust = DCR_Customer.filter(function (a) {
                            mcdt = new Date(a.dt);
                            return (a.sf_code == DCR_FForce[j].Sf_Code /*&& a.Cust_Code == myodr[m]["Cust_Code"] */&&
                                (((mcdt.getDate() < 10 ? "0" : "") + mcdt.getDate() + "/" + ((mcdt.getMonth() + 1) < 10 ? "0" : "") + (mcdt.getMonth() + 1) + "/" + mcdt.getFullYear())
                                    == ((dt.getDate() < 10 ? "0" : "") + dt.getDate() + "/" + ((dt.getMonth() + 1) < 10 ? "0" : "") + (dt.getMonth() + 1) + "/" + dt.getFullYear())));
                    })
                    visitout = "";
                        visitout = mycust.length;
                        for (n = 0; n < mycust.length; n++) {
                            if (n > 0) {                           
                                custName += ", ";
                                custAddr += ", ";
                                custSpec += ", ";
                                custCls += ", ";
                            }
                            
                            custName += mycust[n]["Cust_Name"];
                            custAddr += mycust[n]["Cust_Addr"];
                            custSpec += mycust[n]["Cust_Spec"];
                            custCls += mycust[n]["Cust_Cls"];
                        }

                       /* myPrdts = DCR_ProdDts.filter(function (a) {
                            mptdt = new Date(a.dt);
                            return (a.sf_code == DCR_FForce[j].Sf_Code /*&& a.Cust_Code == myodr[m]["Cust_Code"] &&
                                (((mcdt.getDate() < 10 ? "0" : "") + mcdt.getDate() + "/" + ((mcdt.getMonth() + 1) < 10 ? "0" : "") + (mcdt.getMonth() + 1) + "/" + mcdt.getFullYear())
                                    == ((dt.getDate() < 10 ? "0" : "") + dt.getDate() + "/" + ((dt.getMonth() + 1) < 10 ? "0" : "") + (dt.getMonth() + 1) + "/" + dt.getFullYear())));
                        })
                 
                        for (p = 0; p < myPrdts.length; p++) {
                            if (p > 0) {
                                prdQnty += ", ";                                
                            }
                            
                            prdQnty += myPrdts[p]["Quantity"];                            
                        }*/

                    myEntcp = DCR_EventCap.filter(function (a) {
                        medt = new Date(a.dt);
                        return (a.Sf_Code == DCR_FForce[j].Sf_Code &&
                            (((medt.getDate() < 10 ? "0" : "") + medt.getDate() + "/" + ((medt.getMonth() + 1) < 10 ? "0" : "") + (medt.getMonth() + 1) + "/" + medt.getFullYear())
                                == ((dt.getDate() < 10 ? "0" : "") + dt.getDate() + "/" + ((dt.getMonth() + 1) < 10 ? "0" : "") + (dt.getMonth() + 1) + "/" + dt.getFullYear())));
                    })
                    imgUrl = "";
                    for (q = 0; q < myEntcp.length; q++) {
                        if (q > 0) {
                            imgUrl += ", ";
                        }
                        imgUrl += myEntcp[q]["Imgurl"];
                    }

                    ritem["Wtype"] = wTyp;
                    ritem["ClstrName"] = wRut;
                    ritem["remarks"] = rmks;
                    ritem["Route"] = Root;
                    ritem["Session"] = Sesion;
                    ritem["Activity_Date"] = actdate;
                    ritem["POB_Value"] = pobVal;
                    ritem["net_weight_value"] = netwtVal;
                    ritem["stockist_name"] = stkName;
                    ritem["latlong"] = latlg;
                    ritem["Activity_Remarks"] = actRmk;
                    ritem["OrderTyp"] = ordTyp;
                    ritem["Cust_Code"] = custCd;
                    ritem["Cust_Name"] = custName;
                    ritem["Cust_Addr"] = custAddr;
                    ritem["Cust_Spec"] = custSpec;
                    ritem["Cust_Cls"] = custCls;
                    ritem["filters"] =visitout;
                    ritem["Quantity"] = prdQnty;
                    ritem["Imgurl"] = imgUrl;
                    dt.setDate(dt.getDate() + 1);
                    ResultArr.push(ritem);            
                }
                
            }
            var rwStr = "";
            for (il = 0; il < ResultArr.length; il++) {
                rwStr += "<tr>"; 
                for (var key in listobj) {
                    rwStr += "<td>" + ResultArr[il][key] + "</td>";
                }
                rwStr += "</tr>";
            }
            $("#OrderList tbody").html(rwStr);
        }

        
            
        $('#Product').on('change', function() {
            if ($(this).prop("checked") == true) {
                $('#Prod_Qnty').show();
                $('#Prod_SKU').show();
                $('#Prod_Value').show();
            }
            else {
                $('#Prod_Qnty').hide();
                $('#Prod_SKU').hide();
                $('#Prod_Value').hide();
            }
         })

        function clearFields() {
            $('#Ftablerow').hide();
            $('#mforms').val('');
            $('#mforms').selectpicker('refresh');
            $('#txtName').val('');
            $('#mtemp').val('');
            sfCodematch = [];
            $('#sortable1').find('input[type="checkbox"]').prop('checked', false);
           
        }

        

        $(function () {
            var start = moment();
            var end = moment();

            function cb(start, end) {
                $('#reportrange span').html(start.format('DD-MM-YYYY') + ' - ' + end.format('DD-MM-YYYY'));
            }

            $('#reportrange').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            }, cb);

            cb(start, end);
        });
        


        function loadData() {   
           // selectsfcode += "MR4906,";
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_Products",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>','Mn':'"+fdt+"','Yr':'"+tdt+"'}",
                dataType: "json",
                success: function (data) {
                    DCR_Products = JSON.parse(data.d) || [];                     
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_ProdDts",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>','Mn':'"+fdt+"','Yr':'"+tdt+"'}",
                dataType: "json",
                success: function (data) {
                    DCR_ProdDts = JSON.parse(data.d) || [];                   
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_OrderDts",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>','Mn':'"+fdt+"','Yr':'"+tdt+"'}",
                dataType: "json",
                success: function (data) {
                    DCR_OrderDts = JSON.parse(data.d) || [];                    
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_EventCap",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>','Mn':'"+fdt+"','Yr':'"+tdt+"'}",
                dataType: "json",
                success: function (data) {
                    DCR_EventCap = JSON.parse(data.d) || [];                   
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_FForce",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>'}",
                dataType: "json",
                success: function (data) {
                    DCR_FForce = JSON.parse(data.d) || [];                    
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_Dayplan",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>','Mn':'"+fdt+"','Yr':'"+tdt+"'}",
                dataType: "json",
                success: function (data) {
                    DCR_Dayplan = JSON.parse(data.d) || [];                   
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_Customer",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>','Mn':'"+fdt+"','Yr':'"+tdt+"'}",
                dataType: "json",
                success: function (data) {
                    DCR_Customer = JSON.parse(data.d) || [];
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/GetDCR_tourplan",
                data: "{'SF':'"+ selectsfcode +"','Div':'<%=Session["Division_Code"]%>','Mn':'"+fdt+"','Yr':'"+tdt+"'}",
                dataType: "json",
                success: function (data) {
                    DCR_tourplan = JSON.parse(data.d) || [];                   
                },
                error: function (result) {
                    //alert(JSON.stringify(result));
                }
            });

        }   

    </script>
    <script type="text/javascript">
        $(function () {
            $("#sortable1").sortable();
            $("#sortable1").disableSelection();
        });
    </script>
</asp:Content>