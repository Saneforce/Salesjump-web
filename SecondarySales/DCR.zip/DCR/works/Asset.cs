using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DBase_EReport;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;

namespace Bus_EReport
{
    public class Asset
    {
        private string strQry = string.Empty;
        private string strQry1 = string.Empty;

        public DataSet insertAssetGroup(string divcode, string setname)
        {
            DB_EReporting db_ER = new DB_EReporting();
            DataSet dsA = null;

            strQry = "declare @id numeric " +
                     " select @id=isnull(max(Asset_ID),0)+1 from Mas_Asset_Group where Div_code=" + divcode + " " +
                     " insert into Mas_Asset_Group (Asset_ID,AssetGroup_Name,Div_code,Active_flag,Created_Date) values(@id,'" + setname + "'," + divcode + ",0,getDate())";
            try
            {
                dsA = db_ER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsA;
        }

        public int updateAssetGroup(string divcode, string setname, string code)
        {
            int iReturn = -1;
            DB_EReporting db_ER = new DB_EReporting();

            strQry = " update Mas_Asset_Group set AssetGroup_Name='" + setname + "' where Asset_ID='" + code + "'";

            try
            {
                iReturn = db_ER.ExecQry(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iReturn;
        }

        public int deactAssetGroup(string divcode, string code)
        {
            int iReturn = -1;
            DB_EReporting db_ER = new DB_EReporting();

            strQry = " update Mas_Asset_Group set Active_flag=1,Deactivate_Date=getDate() where Asset_ID='" + code + "'";

            try
            {
                iReturn = db_ER.ExecQry(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iReturn;
        }

        public DataSet getAssetGroup(string divcode)
        {
            DB_EReporting db_ER = new DB_EReporting();
            DataSet dsA = null;

            strQry = "select * from Mas_Asset_Group where Div_code=" + divcode + " and Active_flag=0 order by AssetGroup_Name";
            try
            {
                dsA = db_ER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsA;
        }
        public DataSet getAssetGroup(string divcode, string code)
        {
            DB_EReporting db_ER = new DB_EReporting();
            DataSet dsA = null;

            strQry = "select * from Mas_Asset_Group where Div_code=" + divcode + " and Asset_ID='" + code + "'";
            try
            {
                dsA = db_ER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsA;
        }

        public void insertAssetMaster(AssetData adata)
        {
            DB_EReporting db_ER = new DB_EReporting();
            DataSet dss = new DataSet();
            List<AssetDetails> a = adata.arr;

            string sxml = "<ROOT>";
            for (int i = 0; i < a.Count; i++)
            {
                sxml+="<ASSD fld=\""+a[i].afield+"\" val=\""+a[i].avalue+"\" />";
            }
            sxml += "</ROOT>";
            //strQry = "declare @id varchar(50) " +
            //         " select @id=isnull((max(Asset_Det_ID)+1),1) from Mas_Asset_Details where Div_Code=" + adata.divcode + " " +
            //         " insert into  Mas_Asset_Details (Asset_Det_ID,Asset_Det_Name,Asset_Grp_ID,TagNo,Purchase_Date,Remarks,Div_Code) values(@id,'" + adata.aname + "','" + adata.agrp + "','" + adata.atag + "','" + adata.purdt + "','" + adata.aremark + "','" + adata.divcode + "')";

            
            
            //  strQry1= " declare @sl varchar(50) select @sl=isnull((max(Sl_No)+1),1) from Mas_Asset_Add_Inf where Div_Code='" + adata.divcode + "' " +
            //           " insert into Mas_Asset_Add_Inf(Asset_Det_ID,Sl_No,Name,Txtval,Div_Code) values(@id,@sl,'" + a[i].afield + "','" + a[i].avalue + "','" + adata.divcode + "') ";

            //  strQry += strQry1;
            strQry = "exec insertAssetDets '" + adata.divcode + "','" + adata.aname + "','" + adata.atag+ "','" + adata.agrp + "','" +adata.purdt+ "','" +adata.aremark+ "','" + sxml + "'";
              try
              {
                   dss = db_ER.Exec_DataSet(strQry);
              }
              catch (Exception ex)
              {
                  throw ex;
              }
        }

        public void updateAssetMaster(AssetData adata,string code)
        {
            DB_EReporting db_ER = new DB_EReporting();
            DataSet dss = new DataSet();
            List<AssetDetails> a = adata.arr;

            string sxml = "<ROOT>";
            for (int i = 0; i < a.Count; i++)
            {
                sxml += "<ASSD fld=\""+a[i].afield+"\" val=\""+a[i].avalue+"\" />";
            }
            sxml += "</ROOT>";
            strQry = "exec updateAssetMaster '" + adata.divcode + "','" + adata.aname + "','" + adata.atag + "','" + adata.agrp + "','" + adata.purdt + "','" + adata.aremark + "','" + code + "','" + sxml + "'";
            try
            {
                dss = db_ER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public class AssetData
        {
            [JsonProperty("DivCode")]
            public object divcode { get; set; }

            [JsonProperty("AName")]
            public object aname { get; set; }

            [JsonProperty("ATag")]
            public object atag { get; set; }

            [JsonProperty("AGrp")]
            public object agrp { get; set; }

            [JsonProperty("PurDT")]
            public object purdt { get; set; }

            [JsonProperty("ARemark")]
            public object aremark { get; set; }

            [JsonProperty("Arr")]
            public List<AssetDetails> arr { get; set; }
        }
        public class AssetDetails
        {
            [JsonProperty("afield")]
            public object afield { get; set; }

            [JsonProperty("aval")]
            public object avalue { get; set; }
        }

        public DataSet getAssetDetails(string divcode)
        {
            DB_EReporting dbER = new DB_EReporting();
            DataSet dsf = null;

            strQry = "select ad.*,ag.AssetGroup_Name from Mas_Asset_Details ad inner join Mas_Asset_Group ag on ad.Asset_Grp_ID=ag.Asset_ID where ad.Div_Code=" + divcode + " and ad.Active_flag=0 order by ad.Asset_Det_Name";
            
            try
            {
                dsf = dbER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsf;
        }
        public DataSet getAssetDetails(string divcode,string code)
        {
            DB_EReporting dbER = new DB_EReporting();
            DataSet dsf = null;

            strQry = "select ad.*,ag.AssetGroup_Name from Mas_Asset_Details ad inner join Mas_Asset_Group ag on ad.Asset_Grp_ID=ag.Asset_ID where ad.Div_Code=" + divcode + " and ad.Asset_Det_ID='" + code + "' " +
                     " select * from Mas_Asset_Add_Inf where Div_Code=" + divcode + " and Asset_Det_ID='" + code + "'";
            try
            {
                dsf = dbER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsf;
        }

        public int deactivateAsset(string divcode, string code)
        {
            DB_EReporting dbER = new DB_EReporting();
            int dsf = -1;

            strQry = "update Mas_Asset_Details set Active_flag=1 where Div_Code='" + divcode + "' and Asset_Det_ID='" + code + "'";

            try
            {
                dsf = dbER.Exec_Scalar(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsf;
        }

		public DataSet getassetTag(string divcode, string code)
        {
            DB_EReporting dbER = new DB_EReporting();
            DataSet dsf = null;

            strQry = "select * from Mas_Asset_Details where Div_Code=" + divcode + " and TagNo='" + code + "' and Active_flag=0";

            try
            {
                dsf = dbER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsf;
        }


        public void insertAssetTrans(AssetTrans atrans)
        {
            DB_EReporting db_ER = new DB_EReporting();
            DataSet dss = new DataSet();

            strQry = "exec insertAssetTrans '" + atrans.divcode + "','" + atrans.taname + "','" + atrans.tatag + "','" + atrans.thcode + "','" + atrans.tto + "','" + atrans.ttoid + "','" + atrans.taddr + "'";
            try
            {
                dss = db_ER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public class AssetTrans
        {
            [JsonProperty("DivCode")]
            public object divcode { get; set; }

            [JsonProperty("AName")]
            public object taname { get; set; }

            [JsonProperty("ATag")]
            public object tatag { get; set; }

            [JsonProperty("Addr")]
            public object taddr { get; set; }

            [JsonProperty("Transto")]
            public object tto { get; set; }

            [JsonProperty("TranstoID")]
            public object ttoid { get; set; }

            [JsonProperty("TCode")]
            public object thcode { get; set; }
        }


        public DataSet getAssetTrans(string divcode,string code)
        {
            DataSet dsf = null;
            DB_EReporting db = new DB_EReporting();

            strQry = " select ad.*,ag.AssetGroup_Name from Mas_Asset_Details ad inner join Mas_Asset_Group ag on ad.Asset_Grp_ID=ag.Asset_ID where ad.Div_Code='" + divcode + "' and Asset_Det_ID='" + code + "' " +
                     " select * from(select ms.Stockist_Name,td.* from tans_asset_detail td inner join Mas_Stockist ms on ms.Stockist_Code=td.trans_to_id where Trans_to='D' and Asset_ID='" + code + "' " +
                     " union "+
                     " select ld.ListedDr_Name,td.* from tans_asset_detail td inner join Mas_ListedDr ld on ld.ListedDrCode=td.trans_to_id where Trans_to='R' and Asset_ID='" + code + "')as t order by trans_date ";

            try
            {
                dsf = db.Exec_DataSet(strQry);
            }
            catch(Exception ex)
            {
                throw ex;
            }

            return dsf;
        }

		public string insertplantdets(saveplant sp)
        {
            DB_EReporting dbER = new DB_EReporting();
            DataSet dsf = null;
            strQry = "exec insertPlantDets '" +sp.divcode+ "','" +sp.plcode+ "','" +sp.plname+ "','" +sp.place+ "','" +sp.paddr+ "','" +sp.pin+ "'";
            try
            {
                dsf = dbER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return "Success";
        }

        public string updateplantdets(saveplant sp, string pcode)
        {
            DB_EReporting dbER = new DB_EReporting();
            DataSet dsf = null;
            strQry = "exec updatePlantDets '" + sp.divcode + "','" + sp.plcode + "','" + sp.plname + "','" + sp.place + "','" + sp.paddr + "','" + sp.pin + "','" + pcode + "'";
            try
            {
                dsf = dbER.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return "Success";
        }

        public class saveplant
        {
            [JsonProperty("Divcode")]
            public object divcode { get; set; }

            [JsonProperty("Plcode")]
            public object plcode { get; set; }

            [JsonProperty("Plname")]
            public object plname { get; set; }

            [JsonProperty("Pplace")]
            public object place { get; set; }

            [JsonProperty("Paddr")]
            public object paddr { get; set; }

            [JsonProperty("Pin")]
            public object pin { get; set; }
        }

		public DataSet getPlantDets(string divcode)
        {
            DataSet dsf = null;
            DB_EReporting db = new DB_EReporting();

            strQry = "exec getPlant_Details '" + divcode + "'";
            try
            {
                dsf = db.Exec_DataSet(strQry);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return dsf;
        }

        public int DeActivate(string plcode, string stus)
        {
            int iReturn = -1;
            try
            {
                DB_EReporting db = new DB_EReporting();
                strQry = "update Mas_plant set Active_Flag='" + stus + "' where Plant_Id='" + plcode + "'";
                iReturn = db.ExecQry(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return iReturn;
        }

        public int DeActivateTravel(string plcode, string stus)
        {
            int iReturn = -1;
            try
            {
                DB_EReporting db = new DB_EReporting();
                strQry = "update Mas_Modeof_Travel set Active_Flag = '" + stus + "' where Sl_No = '" + plcode + "'";
                iReturn = db.ExecQry(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return iReturn;
        }

        public DataSet getplantdetails(string divcode, string pcode)
        {
            DB_EReporting db = new DB_EReporting();
            DataSet ds = null;
            strQry = "select * from Mas_Plant where Div_code='" + divcode + "' and Plant_Id='" + pcode + "'";
            try
            {
                ds = db.Exec_DataSet(strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ds;
        }
		
    }
}
