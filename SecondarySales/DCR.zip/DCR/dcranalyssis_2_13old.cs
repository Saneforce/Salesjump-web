<%@ Page Language="C#" MasterPageFile="~/Master.master" AutoEventWireup="true" CodeFile="DCR_Analysiss.aspx.cs" Inherits="MasterFiles_DCR_Analysiss" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <link type="text/css" href="../css/SalesForce_New/bootstrap-select.min.css" rel="stylesheet" />
    <link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel = "stylesheet">
    <style>
        .tab {
            float: left;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
            width: 30%;
            height: 300px;
        }

        .tab1 {
            float: right;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
            width: 70%;
            height: 500px;
        }

        .dropdown-menu {
            height: 200px;
            overflow: auto;
        }

        #sortable {
            list-style-type: none;
            margin: 0;
            padding: 0;
            width: 60%;
        }
        #sortable li {
            margin: 0 3px 3px 3px;
            padding: 0.4em;
            padding-left: 1.5em;
            font-size: 1.0em;
            height: 35px;
        }

        #sortable li span {
            position: absolute;
            margin-left: -1.3em;
        }
        #sortable1 {
            list-style-type: none;
            margin: 0;
            padding: 0;
            width: 100%;
        }
        #sortable1 li {
            margin: 0 3px 3px 3px;
            padding: 0.4em;
            padding-left: 1.5em;
            font-size: 0.9em;
            height: 35px;
        }

        #sortable1 li span {
            position: absolute;
            margin-left: -1.3em;
        }
        table {
          border: 1px solid #666;
          width: 100%;
          text-align: center;
        }
        
        th {
          background: #f8f8f8;
          font-weight: bold;
          padding: 2px;
        }
    </style>
    <form runat="server" id="frm1">
        <div class="row">
            <div class="col-lg-12 sub-header">
                DCR Analysis              
            </div>
            <div class="tab">
                <div class="row hiderow" id="Ftablerow" style="margin-bottom: 1rem!important;">
                    <div class="export btn-group" style="float:right;">
                         <div class="col-xs-12 col-sm-12">
                          <!-- <button id="btnSettings" class="btn btn-default dropdown-toggle" aria-label="Export" data-toggle="dropdown" type="button" title="Settings" style="padding-left: 5px;">
                               <i class="fa fa-th-list"></i>
                               <span class="caret"></span>
                           </button>-->
                            <div class="row" style="margin-bottom: 1rem!important;">
                                <div class="TempName" >
                                    <label class='tgl-btn'for="txtName" style="height: 1px;">Name</label>
                                    <input class='tgl tgl-skewed' id="txtName" type='textbox'  />                                       	
                                </div>
                               <ul>
                                <li class="dropdowntemp user user-menu">
                                	<a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                		<span><span id="label1">+</span><i class="caret"></i></span>
                                
                                	</a>
                                     <ul class="dropdown-menu dropdown-custom dropdown-menu-right" id ="sortable1">                                                                                 
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                             <input class='tgl tgl-skewed' id="flid" type='checkbox' value="sf_Name" title="Fieldforce Name" />
                                             <label class='tgl' for="flid" style="height: 1px;">Fieldforce Name</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                             <input class='tgl tgl-skewed' id="jdate" type='checkbox' value="sf_Joining_Date" />
                                             <label class='tgl' for="jdate" style="height: 1px;">Joining Date</label>
                                         </li>                                                                                 
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Designation" type='checkbox' value="Designation" />
                                         	<label class='tgl'  for="Designation" style="height: 1px;"> Designation</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Date" type='checkbox' value="Date" />
                                         	<label class='tgl'for="Date" style="height: 1px;"> Date</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Worktype" type='checkbox' value="Worktype" />
                                         	<label class='tgl-btn'for="Worktype" style="height: 1px;"> Worktype</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Route_Worked" type='checkbox' value="Route_Worked" />
                                         	<label class='tgl-btn'for="Route_Worked" style="height: 1px;"> Route Worked</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Report_Manag_1" type='checkbox' value="Report_Manag_1" />
                                         	<label class='tgl-btn'for="Report_Manag_1" style="height: 1px;"> Reporting Manager 1</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Report_Manag_2" type='checkbox' value="Report_Manag_2" />
                                         	<label class='tgl-btn'for="Report_Manag_2" style="height: 1px;"> Reporting Manager 2</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Route_Plan" type='checkbox' value="Route_Plan" />
                                         	<label class='tgl-btn'for="Route_Plan" style="height: 1px;"> Route as per Tour Plan</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="DCR_Submit_Date" type='checkbox' value="DCR_Submit_Date" />
                                         	<label class='tgl-btn'for="DCR_Submit_Date" style="height: 1px;">DCR Submitted Date</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Daywise_Remark" type='checkbox' value="Daywise_Remark" />
                                         	<label class='tgl-btn'for="Daywise_Remark" style="height: 1px;"> Daywise Remark</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Cust_Name" type='checkbox' value="Cust_Name" />
                                         	<label class='tgl-btn'for="Cust_Name" style="height: 1px;"> Customer Name</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Address" type='checkbox' value="Address" />
                                         	<label class='tgl-btn'for="Address" style="height: 1px;"> Address</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Session" type='checkbox' value="Session" />
                                         	<label class='tgl-btn'for="Session" style="height: 1px;"> Session</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Retail_Code" type='checkbox' value="Retail_Code" />
                                         	<label class='tgl-btn'for="Retail_Code" style="height: 1px;"> Retailer Code</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Retail_Channel" type='checkbox' value="Retail_Channel" />
                                         	<label class='tgl-btn'for="Retail_Channel" style="height: 1px;"> Retailer Channel</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Retail_Class" type='checkbox' value="Retail_Class" />
                                         	<label class='tgl-btn'for="Retail_Class" style="height: 1px;"> Retailer Class</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Order_Date" type='checkbox' value="Order_Date" />
                                         	<label class='tgl-btn'for="Order_Date" style="height: 1px;"> Order Date</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Order_Time" type='checkbox' value="Order_Time" />
                                         	<label class='tgl-btn'for="Order_Time" style="height: 1px;"> Order Time</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Order_Value" type='checkbox' value="Order_Value" />
                                         	<label class='tgl-btn'for="Order_Value" style="height: 1px;"> Order Value</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Order_Type" type='checkbox' value="Order_Type" />
                                         	<label class='tgl-btn'for="Order_Type" style="height: 1px;"> Order Type</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Fld_order1" type='checkbox' value="Fld_order1" style="display:none"/>
                                         	<label class='tgl-btn'  for="Fld_order1" style="height: 1px;"> Field  Order - Primary</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Fld_order2" type='checkbox' value="Fld_order2" style="display:none"/>
                                         	<label class='tgl-btn'  for="Fld_order2" style="height: 1px;"> Field Order - Secondary</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Phone_order1" type='checkbox' value="Phone_order1" style="display:none"/>
                                         	<label class='tgl-btn'  for="Phone_order1" style="height: 1px;"> Phone Order - Primary</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Phone_order2" type='checkbox' value="Phone_order2" style="display:none" />
                                         	<label class='tgl-btn'  for="Phone_order2" style="height: 1px;"> Phone Order - Secondary</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Product" type='checkbox' value="Product" />
                                         	<label class='tgl-btn'for="Product" style="height: 1px;"> Product</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Prod_Qnty" type='checkbox' value="Prod_Qnty" style="display:none"/>
                                         	<label class='tgl-btn'for="Prod_Qnty" style="height: 1px;"> Product Quantity</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Prod_SKU" type='checkbox' value="Prod_SKU" style="display:none"/>
                                         	<label class='tgl-btn'for="Prod_SKU" style="height: 1px;"> Product SKU</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Prod_Value" type='checkbox' value="Prod_Value" style="display:none"/>
                                         	<label class='tgl-btn'for="Prod_Value" style="height: 1px;"> Product Value</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Nett_Weight" type='checkbox' value="Nett_Weight" />
                                         	<label class='tgl-btn'for="Nett_Weight" style="height: 1px;"> Nett Weight</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Att_Status" type='checkbox' value="Att_Status" />
                                         	<label class='tgl-btn'for="Att_Status" style="height: 1px;"> Attendance Status</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Sub_time" type='checkbox' value="Sub_time" />
                                         	<label class='tgl-btn'for="Sub_time" style="height: 1px;">Plan Submission Time</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Dist_Name" type='checkbox' value="Dist_Name" />
                                         	<label class='tgl-btn'for="Dist_Name" style="height: 1px;"> Distributor Name</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Visited_Outlets" type='checkbox' value="Visited_Outlets" />
                                         	<label class='tgl-btn'for="Visited_Outlets" style="height: 1px;"> Visited Outlets for day</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Prod_Catgry" type='checkbox' value="PProd_Catgry" />
                                         	<label class='tgl-btn'for="Prod_Catgry" style="height: 1px;"> Product Category</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="LatLong" type='checkbox' value="LatLong" />
                                         	<label class='tgl-btn'for="LatLong" style="height: 1px;"> Lat & Long</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Remark" type='checkbox' value="Remark" />
                                         	<label class='tgl-btn'for="Remark" style="height: 1px;"> Remark</label>
                                         </li>
                                         <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                         	<input class='tgl tgl-skewed' id="Event_Capture" type='checkbox' value="Event_Capture" />
                                         	<label class='tgl-btn'for="Event_Capture" style="height: 1px;"> Event Capture</label>
                                         </li>
                                         <li>
                                            <button type="button" class="btn btn-secondary"  id="closefields1">Cancel</button>
                                            <button type="button" style="background-color: #1a73e8;" class="btn btn-primary"  id="svfields1">Apply</button>
                                        </li>
                                     </ul>                                    
                                </li>
                            </ul>
                             <ul>                                 
                                 <li class="dropdown user user-menu">
                                	<a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                		<i class="fa fa-th-list"></i>
                                		<span><span id="ctl00_Label1">Settings</span><i class="caret"></i></span>
                                
                                	</a>
                                	<ul class="dropdown-menu dropdown-custom dropdown-menu-right">
                                        <li  class="dropdown-header text-center">
                                            <a href="#" onclick="exceldata('All')">All</a>
                                		</li>
                                		<li  class="dropdown-header text-center">
                                            <a href="#" onclick="exceldata('Temp1')">Temp1</a>
                                		</li>
                                		<li class="dropdown-header text-center">
                                            <a href="#" onclick="exceldata('Temp2')">Temp2</a>
                                        </li>
                                		<li class="dropdown-header text-center">
                                            <a href="#" onclick="exceldata('Temp3')">Temp3</a>
                                        </li>
                                       <!-- <li  class="dropdown-header text-center">
                                            <input class='template tgl-skewed' id="All" type='checkbox' value="All" />
                                            <label class='tgl-btn' for="All" style="height: 1px;">All</label>
                                		</li>
                                		<li  class="dropdown-header text-center">
                                            <input class='template tgl-skewed' id="Temp1" type='checkbox' value="Temp1" />
                                            <label class='tgl-btn' for="Temp1" style="height: 1px;">Temp1</label>
                                		</li>
                                		<li class="dropdown-header text-center">
                                            <input class='template tgl-skewed' id="Temp2" type='checkbox' value="Temp2" />
                                            <label class='tgl-btn' for="Temp2" style="height: 1px;">Temp2</label>
                                        </li>
                                		<li class="dropdown-header text-center">
                                            <input class='template tgl-skewed' id="Temp3" type='checkbox' value="Temp3" />
                                            <label class='tgl-btn' for="Temp3" style="height: 1px;">Temp3</label>
                                        </li>-->
                                	</ul>
                                </li>
                             </ul>
                            </div>
                         </div>
                     </div>
                    <div class="col-xs-12 col-sm-10">
                        <div class="col-xs-12 col-sm-10">
                            <label style="padding-top: 5px;">Template setting</label>
                        </div>
                        <div class="col-xs-12 col-sm-12" style="padding-left: 0px;">
                            <select id="mtemp" style="padding-left: 0px;">
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-10">
                        <div class="col-xs-12 col-sm-10">
                            <label style="padding-top: 5px;">Fieldforce Name</label>
                        </div>
                        <div class="col-xs-12 col-sm-12" style="padding-left: 0px;">
                            <select id="mforms" multiple data-actions-box="true" style="padding-left: 0px;">
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row hiderow" id="Ftablerow1" style="margin-bottom: 1rem!important;">
                    <div class="col-xs-12 col-sm-12">
                        <div class="col-xs-12 col-sm-8">
                            <label style="padding-top: 5px;">Date Selection </label>
                        </div>
                        <div class="col-xs-12 col-sm-10">
                            <span style="float: left; margin-right: 15px;">
                                <div id="reportrange" class="form-control mt-5 mb-5" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                  <span id="ordDate"></span>
                                    <i class="fa fa-caret-down"></i>
                                </div>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div>
                    <div class="col-xs-12 col-sm-10">
                        <div class="col-xs-12 col-sm-5">
                            <button type="button" style="background-color: #1a73e8; float: right;" class="btn btn-primary" id="viewfields">View</button>
                        </div>
                        <div class="col-xs-12 col-sm-5">
                            <button type="button" class="btn btn-primary" style="background-color: #1a73e8; float: right;" id="clearfields">Clear</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab1" style="float: center;overflow-y:scroll;overflow-x:scroll;">
                <div class="tableclass">
                    <table class="table table-hover" id="OrderList" style="font-size:12px;">
                    	<thead class="text-warning">
                    	</thead>
                    	<tbody>
                    	</tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal fade" id="AddFieldsModal" tabindex="-1" style="z-index: 1000000; background: transparent; overflow: auto;" role="dialog" aria-labelledby="AddFieldsModal" aria-hidden="true">
            <div class="modal-dialog" role="document" style="width: 60%;">
                <div class="modal-content" style="height:400px;overflow-y:scroll">
                    <div class="modal-header" style="background-color: #bfefff;">
                        <h4>Activity list column</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row" style="margin-bottom: 1rem!important;">
                            <ul id="sortable" style ="padding-left: 20px;">
                                <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                    <input class='tgl tgl-skewed' id="FieldName" type='checkbox' value="sf_Name" />
                                    <label class='tgl-btn' for="FieldName" style="height: 1px;">Fieldforce Name</label>
                                </li>
                                <li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                    <input class='tgl tgl-skewed' id="JoinDate" type='checkbox' value="sf_Joining_Date" />
                                    <label class='tgl-btn' for="JoinDate" style="height: 1px;">Joining Date</label>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" id="closefields">Cancel</button>
                        <button type="button" style="background-color: #1a73e8;" class="btn btn-primary" data-dismiss="modal" id="svfields">Apply</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script type="text/javascript">

        function exceldata(variable){
            alert(variable+" data display");
            rowkey = [];
            if (variable == 'Temp1')
                rowkey = ['Total', 'Version', 'Office'];
            if (variable == 'Temp2')
                rowkey = ['location', 'Number', 'class'];
            if (variable == 'Temp3')
                rowkey = ['Total1', 'location1', 'Number1'];
            if (variable == 'All') {
                 for (var j = 0; j < Object.keys(data[0]).length; j++) 
                 rowkey.push(Object.keys(data[0])[j]);
            }
           // drawTable(data);
        }
        
        var data = [{
          "Total": 34,
          "sf_code":"admin",
          "Version": "1.0.4",
          "Office": "New York",
          "location": "Chennai",
          "Number": "12",
          "class": "junior",
          "Total1": 34,
          "Version1": "1.0.4",
          "Office1": "New York",
          "location1": "Chennai",
          "Number1": "12",
          "class1": "junior"
        }, {
          "Total": 67,
          "sf_code":"admin",
          "Version": "1.1.0",
          "Office": "Paris",
          "location": "Cuddalore",
          "Number": "25",
          "class": "senior",
          "Total1": 34,
          "Version1": "1.0.4",
          "Office1": "New York",
          "location1": "Chennai",
          "Number1": "12",
          "class1": "junior"
        },{
          "Total": 37,
          "sf_code":"MR2690",
          "Version": "1.0.5",
          "Office": "Newcityk",
          "location": "Chennai",
          "Number": "12",
          "class": "senoior",
          "Total1": 36,
          "Version1": "3.4.5",
          "Office1": "cenoak",
          "location1": "cud",
          "Number1": "45",
          "class1": "senior"
        }];

        
        var MasFrms = [], dropdownval = '', rowkey = [], fnamematch = [], tempName = [], tempList = [];
        var templatelist = '', templateName = '';
        function loadMasForms() {
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/getForms",
                data: "{'divcode':'<%=Session["div_code"]%>','sfcode':'<%=Session["Sf_Code"]%>'}",
                dataType: "json",
                success: function (data) {
                    MasFrms = JSON.parse(data.d) || [];
                    var fillfrms = MasFrms;
                    $('#mforms').empty();

                    for ($i = 0; $i < fillfrms.length; $i++) {
                        $('#mforms').append('<option value="' + fillfrms[$i].Sf_Code + '">' + fillfrms[$i].Sf_Name + '</option>');
                    }

                },
                error: function (result) {
                    alert(JSON.stringify(result));
                }
            });
            $('#mforms').selectpicker({
                liveSearch: true
            });
            $('#mforms').addClass('col-xs-12').selectpicker('setStyle');
        }

        $(document).ready(function () {
            loadMasForms();
            Tabledata('', '');
        });

        $('#btnSettings').on('click', function () {
            //$('#AddFieldsModal').modal('toggle');
        }); 
        $('#closefields').on('click', function () {
            clearFields();
        }); 
        $('#svfields1').on('click', function () {
            templateName = $('#txtName').val();
            if (templateName == '')
                alert("Please Give Template Name");
            else {
                $('.tgl').each(function () {
                if ($(this).prop("checked") == true)
                    templatelist +=  '"'+ $(this).val() + '":"' +  $(this).next('label').text()+ '",';
                });
                templatelist = '{' + templatelist.substring(0, templatelist.length - 1) + '}';
            }
            alert(templatelist);
            Tabledata(templateName, templatelist);

        });

        function Tabledata(templateName, templatelist) {
            var tempData;

            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/savetemplate",
                data: "{'divcode':'<%=Session["div_code"]%>','tpname':'" + templateName + "','tplist':'" + templatelist + "'}",
                dataType: "json",
                success: function (data) {
                    tempData = JSON.parse(data.d) || [];
                    $('#mtemp').empty();
                    for (var i = 0; i <tempData.length; i++) {
                        tempName.push(tempData[i].template_name);
                        tempList.push(tempData[i].template_list);
                       // tec = JSON.parse(tempData[i].template_list) || [];
                        $('#mtemp').append('<option value="' + tempData[i].template_name + '">' + tempData[i].template_name + '</option>');
                    }
                    //alert(tec);                    
                },
                error: function (result) {
                    alert(JSON.stringify(result));
                }
            });
        }

        $('#mtemp').on('change', function () {
            var select = $('#mtemp :selected').val();
            alert(select);
            for (var i = 0; i < tempName.length; i++) {
                if (tempName[i] == $('#mtemp :selected').val()) {
                    var listobj = JSON.parse(tempList[i]) || [];
                    for (var key in listobj) {
                        alert(' name=' + key + ' value=' + listobj[key]);
                    }
                }
            }
        })

        $('#Order_Type').on('change', function() {
            if ($(this).prop("checked") == true) {
                $('#Fld_order1').show();
                $('#Fld_order2').show();
                $('#Phone_order1').show();
                $('#Phone_order2').show();
            }
            else {
                $('#Fld_order1').hide();
                $('#Fld_order2').hide();
                $('#Phone_order1').hide();
                $('#Phone_order2').hide();
            }
        })
        $('#Product').on('change', function() {
            if ($(this).prop("checked") == true) {
                $('#Prod_Qnty').show();
                $('#Prod_SKU').show();
                $('#Prod_Value').show();
            }
            else {
                $('#Prod_Qnty').hide();
                $('#Prod_SKU').hide();
                $('#Prod_Value').hide();
            }
         })

        function clearFields() {
            $('#mforms').val('');
            $('#mforms').selectpicker('refresh');
            $('#sortable').find('input[type="checkbox"]').prop('checked', false);
           
        }

        function getViewFields() {
            alert('Field Value got');
            var sfcode = '';
            var dateselect = '';
            var settingList = '';
            fnamematch = [];
            $('#mforms :selected').each(function () {
                sfcode += $(this).val() + ',';
                fnamematch.push($(this).val());
            });
            $('.tgl').each(function () {
                if ($(this).prop("checked") == true)
                    settingList += $(this).val() + ',';
            });
            dateselect = $('#ordDate').text();
            $("#OrderList thead").html("");
            $("#OrderList tbody").html("");

            alert(sfcode);
            alert(dateselect);
            alert(settingList);

           // rowkey = [];
            
            /*$('.template').each(function () {
                if ($(this).prop("checked") == true) {
                    if ($(this).val() == 'Temp1')
                        rowkey = ['Total', 'Version', 'Office'];
                    if ($(this).val() == 'Temp2')
                        rowkey = ['location', 'Number', 'class'];
                    if ($(this).val() == 'Temp3')
                        rowkey = ['Total1', 'location1', 'Number1'];
                    if ($(this).val() == 'All'){
                        for (var j = 0; j < Object.keys(data[0]).length; j++) 
                        rowkey.push(Object.keys(data[0])[j]);
                    }
                }            
            });*/

            drawTable(data);
        }

        $('#clearfields').on('click', function () {
            clearFields();
            alert('fields cleared');
        })
        $('#viewfields').on('click', function () {
            getViewFields();
        })

        $(function () {
            var start = moment();
            var end = moment();

            function cb(start, end) {
                $('#reportrange span').html(start.format('DD-MM-YYYY') + ' - ' + end.format('DD-MM-YYYY'));
            }

            $('#reportrange').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            }, cb);

            cb(start, end);
        });
             
       
        function drawTable(data) {
            $("#OrderList thead").html("");
            $("#OrderList tbody").html("");	
            /*rowkey = [];
        
          // Get Table headers and print
          var head = $("<tr />")
            for (var j = 0; j < Object.keys(data[0]).length; j++) {
                rowkey.push(Object.keys(data[0])[j]);    
            head.append($("<th>" + Object.keys(data[0])[j] + "</th>"));
        	$("#OrderList thead").append(head);
            }*/
            var head = $("<tr />")
            for (var j = 0; j < rowkey.length; j++) {
                head.append($("<th>" +rowkey[j] + "</th>"));
        	    $("#OrderList thead").append(head);
            }
          for (var i = 0; i < data.length; i++) {
            drawRow(data[i]);
          }
        }
        
        function drawRow(rowData) {
            if (fnamematch != []) {
                for (i = 0; i < fnamematch.length; i++) {
                    if (rowData.sf_code == fnamematch[i])  {
                        var row1 = $("<tr />")
                        for (var j = 0; j < rowkey.length; j++) {
                            var propertyname = rowkey[j];

                            row1.append($("<td>" + rowData[propertyname] + "</td>"));
                        }
                        $("#OrderList tbody").append(row1);
                    }
                }
            }
            else {
                var row = $("<tr />")
                for (var j = 0; j < rowkey.length; j++) {
                    var propertyname = rowkey[j];
                    
                    row.append($("<td>" + rowData[propertyname]+ "</td>"));
                }
                $("#OrderList tbody").append(row);
            }  
        }
    </script>
    <script type="text/javascript">

        /*$(function () {
            $("#sortable").sortable();
            $("#sortable").disableSelection();
        });*/
        $(function () {
            $("#sortable1").sortable();
            $("#sortable1").disableSelection();
        });

    </script>
</asp:Content>
