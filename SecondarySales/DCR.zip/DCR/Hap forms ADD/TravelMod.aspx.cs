﻿using Bus_EReport;
using ClosedXML.Excel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterFiles_TravelMod : System.Web.UI.Page
{
    public static DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    [WebMethod]
    public static string saveTravelMode(string data)
    {
        string msg = string.Empty;
        Bus_EReport.SalesForce.SaveSalesForce Data = JsonConvert.DeserializeObject<Bus_EReport.SalesForce.SaveSalesForce>(data);
        SalesForce dss = new SalesForce();
        msg = dss.SaveNewTravelMode(Data);
        return msg;
    }
    [WebMethod]
    public static string getTravelModeFields(string divcode)
    {
        AdminSetup Ad = new AdminSetup();
        ds = Ad.getTravel_ModeFields(divcode);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }

    [WebMethod(EnableSession = true)]
    public static int SetTravelStatus(string SF, string stus)
    {
        Asset ast = new Asset();
        int iReturn = ast.DeActivateTravel(SF, stus);
        return iReturn;
    }
    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("MOT");
        dt.Columns.Add("Meter Reading");
        dt.Columns.Add("Fuelcharge");
        dt.Columns.Add("Driver");
        dt.Columns.Add("Allowance");
        dt.Columns.Add("Status");
       
        foreach (DataRow dr in ds.Tables[0].Rows)
        {
            DataRow dtr = dt.NewRow();
            dtr["MOT"] = dr["MOT"].ToString();
            dtr["Meter Reading"] = dr["StEndNeed"].ToString();
            dtr["Fuelcharge"] = dr["FuelAmt"].ToString();
            dtr["Driver"] = dr["DriverNeed"].ToString();
            dtr["Allowance"] = dr["Alw_Eligibilty"].ToString();
            dtr["Status"] = dr["Flag"].ToString();
            dt.Rows.Add(dtr);
        }

        using (XLWorkbook wb = new XLWorkbook())
        {
            wb.Worksheets.Add(dt, "Travel Mode Report");
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename=Travel_Mode_Report.xlsx");
            using (MemoryStream MyMemoryStream = new MemoryStream())
            {
                wb.SaveAs(MyMemoryStream);
                MyMemoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
            }
        }
    }
}