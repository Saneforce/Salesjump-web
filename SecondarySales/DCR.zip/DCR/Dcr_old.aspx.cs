<%@ Page Language="C#" MasterPageFile="~/Master.master" AutoEventWireup="true" CodeFile="DCR_Analysiss.aspx.cs" Inherits="MasterFiles_DCR_Analysiss" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
     <link type="text/css" href="../css/SalesForce_New/bootstrap-select.min.css" rel="stylesheet" />
    <form runat="server" id="frm1">
        <div class="row">
            <div class="col-lg-12 sub-header">DCR Analysis              
            </div>
            <div class="tab">
                <div class="row hiderow" id="Ftablerow" style="margin-bottom: 1rem!important;">
	                <div class="col-xs-12 col-sm-10">
	                	<div class="col-xs-12 col-sm-10">
	                		<label style="padding-top: 5px;">Fieldforce Name</label>
	                	</div>
	                	<div class="col-xs-12 col-sm-12" style ="padding-left: 0px;">
	                		<select id="mforms" multiple  data-actions-box="true" style ="padding-left: 0px;">
	                		</select>
	                	</div>
    	            </div>
                </div>
                <div class="row hiderow" id="Ftablerow1" style="margin-bottom: 1rem!important;">
	                <div class="col-xs-12 col-sm-12">
	                	<div class="col-xs-12 col-sm-8">
	                		<label style="padding-top: 5px;">Date Selection </label>
	                	</div>
	                	<div class="col-xs-12 col-sm-10">
	                		<span style="float: left; margin-right: 15px;">
                               <div id="reportrange" class="form-control mt-5 mb-5" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc;">
                                  <i class="fa fa-calendar"></i>&nbsp;
                                  <span id="ordDate"></span>
                                  <i class="fa fa-caret-down"></i>
                              </div>
                           </span>
	                	</div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-10">
                     <div class="col-xs-12 col-sm-6">
                         <button type="button" style="float: left;" class="btn btn-primary" id="settings">Settings</button>
                         <span id= "settingsrange" style="float: left; margin-right: 15px;"> 
                        </span>
                     </div>
                    <div class="col-xs-12 col-sm-5">
                    </div>
                </div>
                <div>
                    <div class="col-xs-12 col-sm-10">
                        <div class="col-xs-12 col-sm-5">
                            <button type="button" style="background-color: #1a73e8;float: right;" class="btn btn-primary" id="viewfields">View</button>
                        </div>
                        <div class="col-xs-12 col-sm-5">
                            <button type="button" class="btn btn-primary" style="background-color: #1a73e8;float: right;" id="clearfields">Clear</button>
                        </div>
                    </div>                      
                </div>
            </div>
             <div class="tab1" style="float:center;">
                <div class="col-xs-12 col-sm-8">
	                		<label style="padding-top: 5px;">second tab </label>
	                	</div>
                 </div>
         </div>
    </form>
    <script type="text/javascript">
       
        var MasFrms = [];
        function loadMasForms() {
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/getForms",
                data: "{'divcode':'<%=Session["div_code"]%>','sfcode':'<%=Session["Sf_Code"]%>'}",
                dataType: "json",
                success: function (data) {
                    MasFrms = JSON.parse(data.d) || [];
                    var fillfrms = MasFrms;                   
                    $('#mforms').empty();
                   
                    for ($i = 0; $i < fillfrms.length; $i++) {
                        $('#mforms').append('<option value="' + fillfrms[$i].Sf_Name + '">' + fillfrms[$i].Sf_Name + '</option>');
                    }

                },
                error: function (result) {
                    alert(JSON.stringify(result));
                }
            });
            $('#mforms').selectpicker({
                liveSearch: true
            });
            $('#mforms').addClass('col-xs-12').selectpicker('setStyle');
            
        }

         $(document).ready(function () {
             loadMasForms();
         });

         function clearFields() {
             $('#mforms').val('');
             $('#mforms').selectpicker('refresh');
             $('#Ftablerow').val('');
             $('#Ftablerow1').clearFields();
        }
        function getViewFields() {
            alert('Field Value got');
            var fname = '',datesel = '';
            fname += ('#mforms').find('option:selected').text() + ',';
                $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                async: false,
                url: "DCR_Analysiss.aspx/getForms",
                data: "{'divcode':'<%=Session["div_code"]%>','sfcode':'<%=Session["Sf_Code"]%>'}",
                dataType: "json",
                success: function (data) {
                    MasFrms = JSON.parse(data.d) || [];
                    var fillfrms = MasFrms;                   
                    $('#mforms').empty();
                   
                    for ($i = 0; $i < fillfrms.length; $i++) {
                        $('#mforms').append('<option value="' + fillfrms[$i].FieldforceName + '">' + fillfrms[$i].FieldforceName + '</option>');
                    }

                },
                error: function (result) {
                    alert(JSON.stringify(result));
                }
            });
        }

        $('#clearfields').on('click', function () {
            clearFields();
            alert('fields cleared');
        })
        $('#viewfields').on('click', function () {
            getViewFields();
        })
        /*$('#settings').on('click', function () {
            $('#settingsrange'). 
        })*/

        
        $(function () {
            var start = moment();
            var end = moment();

            function cb(start, end) {
                $('#reportrange span').html(start.format('DD-MM-YYYY') + ' - ' + end.format('DD-MM-YYYY'));
            }

            $('#reportrange').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            }, cb);

            cb(start, end);
        });
    </script>
    <style>
    .tab {
      float: left;
      border: 1px solid #ccc;
      background-color: #f1f1f1;
      width: 30%;
      height: 300px;
    }
    .tab1 {
      float: right;
      border: 1px solid #ccc;
      background-color: #f1f1f1;
      width: 70%;
      height: 500px;
    }
    </style>
</asp:Content>