using Bus_EReport;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterFiles_DCR_Analysiss : System.Web.UI.Page
{
    public static string divcode = string.Empty;
    public static string sfcode = string.Empty;
    public static string fdt = string.Empty;
    public static string tdt = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    [WebMethod]
    public static string getForms(string divcode,string sfcode)
    {
        DataSet ds = new DataSet();
        SalesForce Ad = new SalesForce();
        ds = Ad.SalesForceList(divcode, sfcode);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string getTableForms(string divcode, string sfname, string date ,string settinglist)
    {
        DataSet ds = new DataSet();
        SalesForce Ad = new SalesForce();
        ds = Ad.SalesForceList(divcode, sfname);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string savetemplate(string divcode, string tpname, string tplist)
    {
        string result;
        SalesForce Ad = new SalesForce();
        result = Ad.SaveTemplateList(divcode, tpname, tplist);
        return result;
    }

    [WebMethod]
    public static string getTemplate(string divcode)
    {
        DataTable dt = new DataTable();
        SalesForce Ad = new SalesForce();
        dt = Ad.GetDcrTemplateList(divcode);
        return JsonConvert.SerializeObject(dt);
    }

    [WebMethod] 
    public static string GetDCR_Products(string SF, string Div, string Mn, string Yr)
    {
        divcode = Div;
        sfcode = SF;
        fdt = Mn;
        tdt = Yr;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_Products_Details(SF, Div, Mn, Yr);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }

    [WebMethod]
    public static string GetDCR_ProdDts(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_ProdDts_Details(SF, Div, Mn, Yr);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    
    [WebMethod]
    public static string GetDCR_OrderDts(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_OrderDts_Details(SF, Div, Mn, Yr);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_EventCap(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_EventCap_Details(SF, Div, Mn, Yr);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_FForce(string SF, string Div)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        DataTable DCR_FForce_dt = new DataTable();
        ds = SFD.GetDCR_FForce_Details(SF, Div);
        DCR_FForce_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_Dayplan(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_Dayplan_Details(SF, Div, Mn, Yr);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_Customer(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_Customer_Details(SF, Div, Mn, Yr);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    
    [WebMethod]
    public static string GetDCR_tourplan(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_tourplan_Details(SF, Div, Mn, Yr);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
}
