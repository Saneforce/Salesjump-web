using Bus_EReport;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterFiles_DCR_Analysiss : System.Web.UI.Page
{
    public static string divcode = string.Empty;
    public static string sfcode = string.Empty;
    public static string fdt = string.Empty;
    public static string tdt = string.Empty;
    public static DataTable DCR_Dayplan_dt = new DataTable();
    public static DataTable DCR_FForce_dt = new DataTable();
    public static DataTable DCR_Customer_dt = new DataTable();
    public static DataTable DCR_tourplan_dt = new DataTable();
    public static DataTable DCR_OrderDts_dt = new DataTable();
    public static DataTable DCR_Products_dt = new DataTable();
    public static DataTable DCR_ProdDts_dt = new DataTable();
    public static DataTable DCR_EventCap_dt = new DataTable(); 
    public static DataTable finaldt = new DataTable();


    protected void Page_Load(object sender, EventArgs e)
    {

    }
    [WebMethod]
    public static string getForms(string divcode,string sfcode)
    {
        DataSet ds = new DataSet();
        SalesForce Ad = new SalesForce();
        ds = Ad.SalesForceList(divcode, sfcode);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string getTableForms(string divcode, string sfname, string date ,string settinglist)
    {
        DataSet ds = new DataSet();
        SalesForce Ad = new SalesForce();
        ds = Ad.SalesForceList(divcode, sfname);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string savetemplate(string divcode, string tpname, string tplist)
    {
        string result;
        SalesForce Ad = new SalesForce();
        result = Ad.SaveTemplateList(divcode, tpname, tplist);
        return result;
    }

    [WebMethod]
    public static string getTemplate(string divcode)
    {
        DataTable dt = new DataTable();
        SalesForce Ad = new SalesForce();
        dt = Ad.GetDcrTemplateList(divcode);
        return JsonConvert.SerializeObject(dt);
    }

    [WebMethod] 
    public static string GetDCR_Products(string SF, string Div, string Mn, string Yr)
    {
        divcode = Div;
        sfcode = SF;
        fdt = Mn;
        tdt = Yr;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_Products_Details(SF, Div, Mn, Yr);
        DCR_Products_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }

    [WebMethod]
    public static string GetDCR_ProdDts(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_ProdDts_Details(SF, Div, Mn, Yr);
        DCR_ProdDts_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    
    [WebMethod]    
    public static string GetDCR_OrderDts(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_OrderDts_Details(SF, Div, Mn, Yr);
        DCR_OrderDts_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_EventCap(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_EventCap_Details(SF, Div, Mn, Yr);
        DCR_EventCap_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_FForce(string SF, string Div)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
       
        ds = SFD.GetDCR_FForce_Details(SF, Div);
        DCR_FForce_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_Dayplan(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();        
        ds = SFD.GetDCR_Dayplan_Details(SF, Div, Mn, Yr);
        DCR_Dayplan_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_Customer(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_Customer_Details(SF, Div, Mn, Yr);
        DCR_Customer_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    
    [WebMethod]
    public static string GetDCR_tourplan(string SF, string Div, string Mn, string Yr)
    {
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_tourplan_Details(SF, Div, Mn, Yr);
        DCR_tourplan_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }

    [WebMethod]
    public static string joinFForceDayPlan(string SF, string Div, string Mn, string Yr)
    {
        DataTable rs1 = new DataTable();
        DataTable rs2 = new DataTable();
        DataTable rs3 = new DataTable();
        DataTable rs4 = new DataTable();
        DataTable rs5 = new DataTable();
        DataTable rs6 = new DataTable();

        rs1 = null;
        rs2 = null;
        rs3 = null;
        rs4 = null;
        rs5 = null;
        rs6 = null;

        var JoinResultEventCap = (from r1 in DCR_FForce_dt.AsEnumerable()
                                  join t1 in DCR_Dayplan_dt.AsEnumerable()
                                  on r1.Field<string>("sf_code") equals t1.Field<string>("sf_code")
                                   into tempJoin
                                  from temp in tempJoin.DefaultIfEmpty()
                                  select new
                                  {
                                      Sf_Name = r1.Field<string>("Sf_Name"),
                                      sf_code = r1.Field<string>("sf_code"),
                                      Sf_Joining_Date = r1.Field<string>("Sf_Joining_Date"),
                                      Reporting_Sf = r1.Field<string>("Reporting_Sf"),
                                      Reporting = r1.Field<string>("Reporting"),
                                      Designation = r1.Field<string>("Designation"),
                                      dt = (temp == null ? string.Empty : temp.Field<string>("dt")),
                                      Wtype = (temp == null ? string.Empty : temp.Field<string>("Wtype")),
                                      remarks = (temp == null ? string.Empty : temp.Field<string>("remarks")),
                                      ClstrName = (temp == null ? string.Empty : temp.Field<string>("ClstrName"))
                                  }).ToList();
        rs1 = LINQResultToDataTable(JoinResultEventCap);
        var joinResultFforce = (from r2 in rs1.AsEnumerable()
                                join t2 in DCR_Customer_dt.AsEnumerable()
                                on new
                                {
                                    JoinProperty1 = r2.Field<string>("sf_code"),
                                    JoinProperty2 = r2.Field<string>("dt")
                                }
                                equals
                                new
                                {
                                    JoinProperty1 = t2.Field<string>("sf_code"),
                                    JoinProperty2 = t2.Field<string>("dt")
                                } into tempJoin1
                                from temp1 in tempJoin1.DefaultIfEmpty()

                                join t3 in DCR_tourplan_dt.AsEnumerable()
                                on new
                                {
                                    JoinProperty1 = r2.Field<string>("sf_code"),
                                    JoinProperty2 = r2.Field<string>("dt")
                                }
                                equals
                                new
                                {
                                    JoinProperty1 = t3.Field<string>("sf_code"),
                                    JoinProperty2 = t3.Field<string>("dt")
                                } into tempJoin2
                                from temp2 in tempJoin2.DefaultIfEmpty()

                                join t4 in DCR_EventCap_dt.AsEnumerable()
                                on new
                                {
                                    JoinProperty1 = r2.Field<string>("sf_code"),
                                    JoinProperty2 = r2.Field<string>("dt")
                                }
                                equals
                                new
                                {
                                    JoinProperty1 = t4.Field<string>("sf_code"),
                                    JoinProperty2 = t4.Field<string>("dt")
                                } into tempJoin3
                                from temp3 in tempJoin3.DefaultIfEmpty()
                                select new
                                {
                                    Sf_Name = r2.Field<string>("Sf_Name"),
                                    sf_code = r2.Field<string>("sf_code"),
                                    Sf_Joining_Date = r2.Field<string>("Sf_Joining_Date"),
                                    Reporting_Sf = r2.Field<string>("Reporting_Sf"),
                                    Reporting = r2.Field<string>("Reporting"),
                                    Designation = r2.Field<string>("Designation"),
                                    dt = r2.Field<string>("dt"),
                                    Wtype = r2.Field<string>("Wtype"),
                                    remarks = r2.Field<string>("remarks"),
                                    ClstrName = r2.Field<string>("ClstrName"),
                                    Cust_Code = (temp1 == null ? 0 : temp1.Field<Decimal>("Cust_Code")),
                                    Cust_Name = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Name")),
                                    Cust_Addr = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Addr")),
                                    Cust_Cls = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Cls")),
                                    Cust_Spec = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Spec")),
                                    Route = (temp2 == null ? string.Empty : temp2.Field<string>("Route")),
                                    Imgurl = (temp3 == null ? string.Empty : temp3.Field<string>("Imgurl"))
                                }).ToList();
        rs2 = LINQResultToDataTable(joinResultFforce);
        var rs2count = rs2.Rows.Count;

        var JoinResultOrderDts = (from r3 in rs2.AsEnumerable()
                                  join t5 in DCR_OrderDts_dt.AsEnumerable()
                                  on new
                                  {
                                      JoinProperty1 = r3.Field<string>("sf_code"),
                                      JoinProperty2 = r3.Field<string>("dt"),
                                      JoinProperty3 = r3.Field<Decimal>("Cust_Code")
                                  }
                                  equals
                                  new
                                  {
                                      JoinProperty1 = t5.Field<string>("sf_code"),
                                      JoinProperty2 = t5.Field<string>("dt"),
                                      JoinProperty3 = t5.Field<Decimal>("Cust_Code")
                                  } into tempJoin4
                                  from temp4 in tempJoin4.DefaultIfEmpty()

                                  select new
                                  {
                                      Sf_Name = r3.Field<string>("Sf_Name"),
                                      sf_code = r3.Field<string>("sf_code"),
                                      Sf_Joining_Date = r3.Field<string>("Sf_Joining_Date"),
                                      Reporting_Sf = r3.Field<string>("Reporting_Sf"),
                                      Reporting = r3.Field<string>("Reporting"),
                                      Designation = r3.Field<string>("Designation"),
                                      dt = r3.Field<string>("dt"),
                                      Wtype = r3.Field<string>("Wtype"),
                                      remarks = r3.Field<string>("remarks"),
                                      ClstrName = r3.Field<string>("ClstrName"),
                                      Cust_Code = r3.Field<Decimal>("Cust_Code"),
                                      Cust_Name = r3.Field<string>("Cust_Name"),
                                      Cust_Addr = r3.Field<string>("Cust_Addr"),
                                      Cust_Cls = r3.Field<string>("Cust_Cls"),
                                      Cust_Spec = r3.Field<string>("Cust_Spec"),
                                      Route = r3.Field<string>("Route"),
                                      Imgurl = r3.Field<string>("Imgurl"),
                                      Activity_Date = (temp4 == null ? string.Empty : temp4.Field<string>("Activity_Date")),
                                      OrderTyp = (temp4 == null ? string.Empty : temp4.Field<string>("OrderTyp")),
                                      POB_Value = (temp4 == null ? 0 : temp4.Field<Double>("POB_Value")),
                                      Session = (temp4 == null ? string.Empty : temp4.Field<string>("Session")),
                                      latlong = (temp4 == null ? string.Empty : temp4.Field<string>("latlong")),
                                      net_weight_value = (temp4 == null ? 0 : temp4.Field<Double>("net_weight_value")),
                                      stockist_name = (temp4 == null ? string.Empty : temp4.Field<string>("stockist_name")),
                                      Activity_Remarks = (temp4 == null ? string.Empty : temp4.Field<string>("Activity_Remarks"))
                                  }).ToList();

        rs3 = LINQResultToDataTable(JoinResultOrderDts);
        var rs4count = rs3.Rows.Count;
        return JsonConvert.SerializeObject(rs3);
    }
    public static DataTable LINQResultToDataTable<T>(IEnumerable<T> Linqlist)
    {
        DataTable dt = new DataTable();
        PropertyInfo[] columns = null;
        if (Linqlist == null) return dt;
        foreach (T Record in Linqlist)
        {
            if (columns == null)
            {
                columns = ((Type)Record.GetType()).GetProperties();
                foreach (PropertyInfo GetProperty in columns)
                {
                    Type IcolType = GetProperty.PropertyType;
                    if ((IcolType.IsGenericType) && (IcolType.GetGenericTypeDefinition()
                    == typeof(Nullable<>)))
                    {
                        IcolType = IcolType.GetGenericArguments()[0];
                    }
                    dt.Columns.Add(new DataColumn(GetProperty.Name, IcolType));
                }
            }
            DataRow dr = dt.NewRow();
            foreach (PropertyInfo p in columns)
            {
                dr[p.Name] = p.GetValue(Record, null) == null ? DBNull.Value : p.GetValue(Record, null);
            }
            dt.Rows.Add(dr);
        }
        return dt;
    }
}
