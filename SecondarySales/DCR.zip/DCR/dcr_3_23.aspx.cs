using Bus_EReport;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterFiles_DCR_Analysiss : System.Web.UI.Page
{
    public static string divcode = string.Empty;
    public static string sfcode = string.Empty;
    public static string fdt = string.Empty;
    public static string tdt = string.Empty;
    public static string[] ProdCode;
    public static DataTable DCR_Dayplan_dt = new DataTable();
    public static DataTable DCR_FForce_dt = new DataTable();
    public static DataTable DCR_Customer_dt = new DataTable();
    public static DataTable DCR_tourplan_dt = new DataTable();
    public static DataTable DCR_OrderDts_dt = new DataTable();
    public static DataTable DCR_Products_dt = new DataTable();
    public static DataTable DCR_ProdDts_dt = new DataTable();
    public static DataTable DCR_EventCap_dt = new DataTable(); 
    public static DataTable finaldt = new DataTable();
    public static DataTable DCR_All_dt = new DataTable();
    public static DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    [WebMethod]
    public static string getForms(string divcode,string sfcode)
    {
        DataSet ds = new DataSet();
        SalesForce Ad = new SalesForce();
        ds = Ad.SalesForceList(divcode, sfcode);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string getTableForms(string divcode, string sfname, string date ,string settinglist)
    {
        DataSet ds = new DataSet();
        SalesForce Ad = new SalesForce();
        ds = Ad.SalesForceList(divcode, sfname);
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string savetemplate(string divcode, string tpname, string tplist)
    {
        string result;
        SalesForce Ad = new SalesForce();
        result = Ad.SaveTemplateList(divcode, tpname, tplist);
        return result;
    }

    [WebMethod]
    public static string getTemplate(string divcode)
    {
        DataTable dt = new DataTable();
        SalesForce Ad = new SalesForce();
        dt = Ad.GetDcrTemplateList(divcode);
        return JsonConvert.SerializeObject(dt);
    }

    [WebMethod] 
    public static string GetDCR_Products(string SF, string Div, string Mn, string Yr)
    {
        divcode = Div;
        sfcode = SF;
        fdt = Mn;
        tdt = Yr;
        DCR_Products_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_Products_Details(SF, Div, Mn, Yr);
        DCR_Products_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }

    [WebMethod]
    public static string GetDCR_ProdDts(string SF, string Div, string Mn, string Yr)
    {
        DCR_ProdDts_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_ProdDts_Details(SF, Div, Mn, Yr);
        DCR_ProdDts_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    
    [WebMethod]    
    public static string GetDCR_OrderDts(string SF, string Div, string Mn, string Yr)
    {
        DCR_OrderDts_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_OrderDts_Details(SF, Div, Mn, Yr);
        DCR_OrderDts_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_EventCap(string SF, string Div, string Mn, string Yr)
    {
        DCR_EventCap_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_EventCap_Details(SF, Div, Mn, Yr);
        DCR_EventCap_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_FForce(string SF, string Div)
    {
        DCR_FForce_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
       
        ds = SFD.GetDCR_FForce_Details(SF, Div);
        DCR_FForce_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_Dayplan(string SF, string Div, string Mn, string Yr)
    {
        DCR_Dayplan_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();        
        ds = SFD.GetDCR_Dayplan_Details(SF, Div, Mn, Yr);
        DCR_Dayplan_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_Customer(string SF, string Div, string Mn, string Yr)
    {
        DCR_Customer_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_Customer_Details(SF, Div, Mn, Yr);
        DCR_Customer_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    
    [WebMethod]
    public static string GetDCR_tourplan(string SF, string Div, string Mn, string Yr)
    {
        DCR_tourplan_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_tourplan_Details(SF, Div, Mn, Yr);
        DCR_tourplan_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }
    [WebMethod]
    public static string GetDCR_All_detail(string SF, string Div, string Mn, string Yr)
    {
        DCR_All_dt = null;
        SalesForce SFD = new SalesForce();
        DataSet ds = new DataSet();
        ds = SFD.GetDCR_All_Details(SF, Div, Mn, Yr);
        DCR_All_dt = ds.Tables[0];
        return JsonConvert.SerializeObject(ds.Tables[0]);
    }

    [WebMethod]
    public static string[] uniqueFilter( string key )
    {
        string[] F_uniq_column;
        DataView dv;
        DataTable dt;

        dv = new DataView();
        dt = new DataTable();
        dv = null;
        dt = null;
        F_uniq_column = new string[] { };

        if (key == "Sf_Name" || key == "Sf_Joining_Date" || key == "Reporting_Sf" || key == "Reporting" || key == "Designation")
        {
            dv = new DataView(DCR_FForce_dt);
            dt = DCR_FForce_dt;
        }            
        if(key == "Cust_Code" || key == "Cust_Name" || key == "Cust_Spec" || key == "Cust_Cls" || key == "Cust_Addr" || key == "dt")
        {
            dv = new DataView(DCR_Customer_dt);
            dt = DCR_Customer_dt;
        }
        if (key == "Wtype" || key == "ClstrName" || key == "remarks")
        {
            dv = new DataView(DCR_Dayplan_dt);
            dt = DCR_Dayplan_dt;
        }
        if(key == "Imgurl" || key == "Activity_Report_Code")
        {
            dv = new DataView(DCR_EventCap_dt);
            dt = DCR_EventCap_dt;
        }
        if (key == "Activity_Remarks" || key ==  "Activity_Date" || key == "OrderTyp" || key == "POB_Value" || key == "Session" || key == "latlong" || key == "net_weight_value" || key == "stockist_name")
        {
            dv = new DataView(DCR_OrderDts_dt);
            dt = DCR_OrderDts_dt;
        }
        if (key == "Route")
        {
            dv = new DataView(DCR_tourplan_dt);
            dt = DCR_EventCap_dt;
        }
        if(dt != null)
        {
            F_uniq_column = dt.Columns.Contains(key) ? ((dv.ToTable(true, key)).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_uniq_column;
        }
        
        return F_uniq_column;
    }

    [WebMethod]
    public static  string[] uniqueTableData(string jsonsting,string key,int round)
    {
        string[] F_uniq_Name;
        DataTable dt5;
        DataView dv;

        dt =  null;
        F_uniq_Name = new string[] { };
        //if(key == "Sf_Name")
        //{
        //    key = "sf_code";
        //}
        try
        {
            if (round == 1)
            {
                dt = (DataTable)JsonConvert.DeserializeObject( jsonsting, (typeof(DataTable)));
            }

            dv = new DataView(dt);
            dt5 = new DataTable();
            F_uniq_Name = dt.Columns.Contains(key) ? ((dv.ToTable(true, key)).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_uniq_Name;

        }
        catch (Exception ex)
        {
            File.WriteAllText(@"C:\Users\user\Desktop\DCR\test.txt", ex.Message + ex.StackTrace) ;
        }
        return F_uniq_Name;

    }

    [WebMethod]
    public static Tuple<string[], string[], string[], string[], string[], string[], string[], string[]> uniqueProdCodeee(string jsonsting )
    {
        string[] F_Sf_Name, F_Sf_Joining_Date, F_Designation, F_dt, F_Wtype, F_ClstrName, F_Reporting_Sf, F_Reporting, F_Route, F_remarks, F_Cust_Name, F_Cust_Addr, F_Session, F_Cust_Code, F_Cust_Cls, F_Activity_Date, F_POB_Value, F_OrderTyp, F_Product, F_Quantity, F_Prod_SKU, F_value, F_net_weight_value, F_stockist_name, F_filters, F_latlong, F_Activity_Remarks, F_Imgurl;
        F_Sf_Name = new string[] { }; F_Sf_Joining_Date = new string[] { }; F_Designation = new string[] { }; F_dt = new string[] { }; F_Wtype = new string[] { }; F_ClstrName = new string[] { }; F_Reporting_Sf = new string[] { }; F_Reporting = new string[] { }; F_Route = new string[] { }; F_remarks = new string[] { }; F_Cust_Name = new string[] { }; F_Cust_Addr = new string[] { }; F_Session = new string[] { }; F_Cust_Code = new string[] { }; F_Cust_Cls = new string[] { }; F_Activity_Date = new string[] { }; F_POB_Value = new string[] { }; F_OrderTyp = new string[] { }; F_Product = new string[] { }; F_Quantity = new string[] { }; F_Prod_SKU = new string[] { }; F_value = new string[] { }; F_net_weight_value = new string[] { }; F_stockist_name = new string[] { }; F_filters = new string[] { }; F_latlong = new string[] { }; F_Activity_Remarks = new string[] { }; F_Imgurl = new string[] { };
        DataTable dt = (DataTable)JsonConvert.DeserializeObject(jsonsting, (typeof(DataTable)));
        DataView dv = new DataView(dt);
        DataTable dt5 = new DataTable();
        F_Sf_Name = dt.Columns.Contains("Sf_Name") ? ((dv.ToTable(true, "Sf_Name")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Sf_Name;
        //F_Sf_Name = (dv.ToTable(true, "Sf_Name", "Sf_Joining_Date", "Cust_Name")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray();
        F_Sf_Name = dt.Columns.Contains("Sf_Name") ?((dv.ToTable(true, "Sf_Name")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Sf_Name;
        F_Sf_Joining_Date = dt.Columns.Contains("Sf_Joining_Date") ? ((dv.ToTable(true, "Sf_Joining_Date")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Sf_Joining_Date;
        F_Designation = dt.Columns.Contains("Designation") ? ((dv.ToTable(true, "Designation")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Designation;
        F_dt = dt.Columns.Contains("dt") ? ((dv.ToTable(true, "dt")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_dt;
        F_Wtype = dt.Columns.Contains("Wtype") ? ((dv.ToTable(true, "Wtype")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Wtype;
        F_ClstrName = dt.Columns.Contains("ClstrName") ? ((dv.ToTable(true, "ClstrName")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_ClstrName;
        F_Reporting_Sf = dt.Columns.Contains("Reporting_Sf") ? ((dv.ToTable(true, "Reporting_Sf")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Reporting_Sf;
        F_Reporting = dt.Columns.Contains("Reporting") ? ((dv.ToTable(true, "Reporting")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Reporting;
        F_Route = dt.Columns.Contains("Route") ? ((dv.ToTable(true, "Route")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Route;
        F_remarks = dt.Columns.Contains("remarks") ? ((dv.ToTable(true, "remarks")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_remarks;
        F_Cust_Name = dt.Columns.Contains("Cust_Name") ? ((dv.ToTable(true, "Cust_Name")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Cust_Name;
        F_Cust_Addr = dt.Columns.Contains("Cust_Addr") ? ((dv.ToTable(true, "Cust_Addr")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Cust_Addr;
        F_Session = dt.Columns.Contains("Session") ? ((dv.ToTable(true, "Session")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Session;
        F_Cust_Code = dt.Columns.Contains("Cust_Code") ? ((dv.ToTable(true, "Cust_Code")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Cust_Code;
        F_Cust_Cls = dt.Columns.Contains("Cust_Cls") ? ((dv.ToTable(true, "Cust_Cls")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Cust_Cls;
        F_Activity_Date = dt.Columns.Contains("Activity_Date") ? ((dv.ToTable(true, "Activity_Date")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Activity_Date;
        F_POB_Value = dt.Columns.Contains("POB_Value") ? ((dv.ToTable(true, "POB_Value")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_POB_Value;
        F_OrderTyp = dt.Columns.Contains("OrderTyp") ? ((dv.ToTable(true, "OrderTyp")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_OrderTyp;
        F_Product = dt.Columns.Contains("Product") ? ((dv.ToTable(true, "Product")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Product;
        F_net_weight_value = dt.Columns.Contains("net_weight_value") ? ((dv.ToTable(true, "net_weight_value")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_net_weight_value;
        F_stockist_name = dt.Columns.Contains("stockist_name") ? ((dv.ToTable(true, "stockist_name")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_stockist_name;
        F_filters = dt.Columns.Contains("filters") ? ((dv.ToTable(true, "filters")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_filters;
        F_latlong = dt.Columns.Contains("latlong") ? ((dv.ToTable(true, "latlong")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_latlong;
        F_Activity_Remarks = dt.Columns.Contains("Activity_Remarks") ? ((dv.ToTable(true, "Activity_Remarks")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Activity_Remarks;
        F_Imgurl = dt.Columns.Contains("Imgurl") ? ((dv.ToTable(true, "Imgurl")).Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray()) : F_Imgurl;

        var tuple = new Tuple<string[], string[], string[], string[], string[], string[], string[], string[]>(F_Sf_Name, F_Sf_Joining_Date, F_Designation, F_dt, F_Wtype, F_ClstrName, F_Reporting_Sf, F_Reporting);
        var tuple2 = new Tuple<string[], string[], string[], string[], string[], string[], string[], string[]>(F_Route, F_remarks, F_Cust_Name, F_Cust_Addr, F_Session, F_Cust_Code, F_Cust_Cls, F_Activity_Date);
        var tuple3 = new Tuple<string[], string[], string[], string[], string[], string[], string[], string[]>(F_POB_Value, F_OrderTyp, F_net_weight_value, F_stockist_name, F_filters, F_latlong, F_Activity_Remarks, F_Imgurl);
        return tuple;
    }
    [WebMethod]
    public static string joinFForceDayPlan(string SF, string Div, string Mn, string Yr)
    {
        DataTable rs1 = new DataTable();
        DataTable rs2 = new DataTable();
        DataTable rs3 = new DataTable();
        DataTable rs4 = new DataTable();
        DataTable rs5 = new DataTable();
        DataTable rs6 = new DataTable();

        rs1 = null;
        rs2 = null;
        rs3 = null;
        rs4 = null;
        rs5 = null;
        rs6 = null;

        /*var JoinResultEventCap = (from r1 in DCR_FForce_dt.AsEnumerable()
                                  join t1 in DCR_Dayplan_dt.AsEnumerable()
                                  on r1.Field<string>("sf_code") equals t1.Field<string>("sf_code")
                                   into tempJoin
                                  from temp in tempJoin.DefaultIfEmpty()
                                  select new
                                  {
                                      Sf_Name = r1.Field<string>("Sf_Name"),
                                      sf_code = r1.Field<string>("sf_code"),
                                      Sf_Joining_Date = r1.Field<string>("Sf_Joining_Date"),
                                      Reporting_Sf = r1.Field<string>("Reporting_Sf"),
                                      Reporting = r1.Field<string>("Reporting"),
                                      Designation = r1.Field<string>("Designation"),
                                      dt = (temp == null ? string.Empty : temp.Field<string>("dt")),
                                      Wtype = (temp == null ? string.Empty : temp.Field<string>("Wtype")),
                                      remarks = (temp == null ? string.Empty : temp.Field<string>("remarks")),
                                      ClstrName = (temp == null ? string.Empty : temp.Field<string>("ClstrName"))
                                  }).ToList();
        rs1 = LINQResultToDataTable(JoinResultEventCap);
        var joinResultFforce = (from r2 in rs1.AsEnumerable()
                                join t2 in DCR_Customer_dt.AsEnumerable()
                                on new
                                {
                                    JoinProperty1 = r2.Field<string>("sf_code"),
                                    JoinProperty2 = r2.Field<string>("dt")
                                }
                                equals
                                new
                                {
                                    JoinProperty1 = t2.Field<string>("sf_code"),
                                    JoinProperty2 = t2.Field<string>("dt")
                                } into tempJoin1
                                from temp1 in tempJoin1.DefaultIfEmpty()

                               join t3 in DCR_tourplan_dt.AsEnumerable()
                                on new
                                {
                                    JoinProperty1 = r2.Field<string>("sf_code"),
                                    JoinProperty2 = r2.Field<string>("dt")
                                }
                                equals
                                new
                                {
                                    JoinProperty1 = t3.Field<string>("sf_code"),
                                    JoinProperty2 = t3.Field<string>("dt")
                                } into tempJoin2
                                from temp2 in tempJoin2.DefaultIfEmpty()

                                join t4 in DCR_EventCap_dt.AsEnumerable()
                                on new
                                {
                                    JoinProperty1 = r2.Field<string>("sf_code"),
                                    JoinProperty2 = r2.Field<string>("dt")
                                }
                                equals
                                new
                                {
                                    JoinProperty1 = t4.Field<string>("sf_code"),
                                    JoinProperty2 = t4.Field<string>("dt")
                                } into tempJoin3
                                from temp3 in tempJoin3.DefaultIfEmpty()
                                select new
                                {
                                    Sf_Name = r2.Field<string>("Sf_Name"),
                                    sf_code = r2.Field<string>("sf_code"),
                                    Sf_Joining_Date = r2.Field<string>("Sf_Joining_Date"),
                                    Reporting_Sf = r2.Field<string>("Reporting_Sf"),
                                    Reporting = r2.Field<string>("Reporting"),
                                    Designation = r2.Field<string>("Designation"),
                                    dt = r2.Field<string>("dt"),
                                    Wtype = r2.Field<string>("Wtype"),
                                    remarks = r2.Field<string>("remarks"),
                                    ClstrName = r2.Field<string>("ClstrName"),
                                    Cust_Code = (temp1 == null ? 0 : temp1.Field<Decimal>("Cust_Code")),
                                    Cust_Name = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Name")),
                                    Cust_Addr = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Addr")),
                                    Cust_Cls = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Cls")),
                                    Cust_Spec = (temp1 == null ? string.Empty : temp1.Field<string>("Cust_Spec")),
                                    Route = (temp2 == null ? string.Empty : temp2.Field<string>("Route")),
                                    Imgurl = (temp3 == null ? string.Empty : temp3.Field<string>("Imgurl"))
                                }).ToList();
        rs2 = LINQResultToDataTable(joinResultFforce);
        var rs2count = rs2.Rows.Count;

        var JoinResultOrderDts = (from r3 in rs2.AsEnumerable()
                                  join t5 in DCR_OrderDts_dt.AsEnumerable()
                                  on new
                                  {
                                      JoinProperty1 = r3.Field<string>("sf_code"),
                                      JoinProperty2 = r3.Field<string>("dt"),
                                      JoinProperty3 = r3.Field<Decimal>("Cust_Code")
                                  }
                                  equals
                                  new
                                  {
                                      JoinProperty1 = t5.Field<string>("sf_code"),
                                      JoinProperty2 = t5.Field<string>("dt"),
                                      JoinProperty3 = t5.Field<Decimal>("Cust_Code")
                                  } into tempJoin4
                                  from temp4 in tempJoin4.DefaultIfEmpty()

                                  select new
                                  {
                                      Sf_Name = r3.Field<string>("Sf_Name"),
                                      sf_code = r3.Field<string>("sf_code"),
                                      Sf_Joining_Date = r3.Field<string>("Sf_Joining_Date"),
                                      Reporting_Sf = r3.Field<string>("Reporting_Sf"),
                                      Reporting = r3.Field<string>("Reporting"),
                                      Designation = r3.Field<string>("Designation"),
                                      dt = r3.Field<string>("dt"),
                                      Wtype = r3.Field<string>("Wtype"),
                                      remarks = r3.Field<string>("remarks"),
                                      ClstrName = r3.Field<string>("ClstrName"),
                                      Cust_Code = r3.Field<Decimal>("Cust_Code"),
                                      Cust_Name = r3.Field<string>("Cust_Name"),
                                      Cust_Addr = r3.Field<string>("Cust_Addr"),
                                      Cust_Cls = r3.Field<string>("Cust_Cls"),
                                      Cust_Spec = r3.Field<string>("Cust_Spec"),
                                      Route = r3.Field<string>("Route"),
                                      Imgurl = r3.Field<string>("Imgurl"),
                                      Activity_Date = (temp4 == null ? string.Empty : temp4.Field<string>("Activity_Date")),
                                      OrderTyp = (temp4 == null ? string.Empty : temp4.Field<string>("OrderTyp")),
                                      POB_Value = (temp4 == null ? 0 : temp4.Field<Double>("POB_Value")),
                                      Session = (temp4 == null ? string.Empty : temp4.Field<string>("Session")),
                                      latlong = (temp4 == null ? string.Empty : temp4.Field<string>("latlong")),
                                      net_weight_value = (temp4 == null ? 0 : temp4.Field<Double>("net_weight_value")),
                                      stockist_name = (temp4 == null ? string.Empty : temp4.Field<string>("stockist_name")),
                                      Activity_Remarks = (temp4 == null ? string.Empty : temp4.Field<string>("Activity_Remarks"))
                                  }).ToList();

        rs3 = LINQResultToDataTable(JoinResultOrderDts);
        
        var rs4count = rs3.Rows.Count;
        var datatypeQuantity = DCR_ProdDts_dt.Columns["Quantity"].DataType;
        var datatypeCust_Code = DCR_ProdDts_dt.Columns["Cust_Code"].DataType;
        var datatypeValue = DCR_ProdDts_dt.Columns["value"].DataType;
        var JoinResultProdDts = (from rf1 in rs3.AsEnumerable()
                                 join t6 in DCR_ProdDts_dt.AsEnumerable()
                                 on new
                                 {
                                     JoinProperty1 = rf1.Field<string>("sf_code"),
                                     JoinProperty2 = rf1.Field<string>("dt"),
                                     JoinProperty3 = rf1.Field<Decimal>("Cust_Code")
                                 }
                                 equals
                                 new
                                 {
                                     JoinProperty1 = t6.Field<string>("sf_code"),
                                     JoinProperty2 = t6.Field<string>("dt"),
                                     JoinProperty3 = t6.Field<Decimal>("Cust_Code")
                                 } into tempJoin5tb
                                 from temp5tb in tempJoin5tb.DefaultIfEmpty()

                                 select new
                                 {
                                     Sf_Name = rf1.Field<string>("Sf_Name"),
                                     sf_code = rf1.Field<string>("sf_code"),
                                     Sf_Joining_Date = rf1.Field<string>("Sf_Joining_Date"),
                                     Reporting_Sf = rf1.Field<string>("Reporting_Sf"),
                                     Reporting = rf1.Field<string>("Reporting"),
                                     Designation = rf1.Field<string>("Designation"),
                                     dt = rf1.Field<string>("dt"),
                                     Wtype = rf1.Field<string>("Wtype"),
                                     remarks = rf1.Field<string>("remarks"),
                                     ClstrName = rf1.Field<string>("ClstrName"),
                                     Cust_Code = rf1.Field<Decimal>("Cust_Code"),
                                     Cust_Name = rf1.Field<string>("Cust_Name"),
                                     Cust_Addr = rf1.Field<string>("Cust_Addr"),
                                     Cust_Cls = rf1.Field<string>("Cust_Cls"),
                                     Cust_Spec = rf1.Field<string>("Cust_Spec"),
                                     Route = rf1.Field<string>("Route"),
                                     Imgurl = rf1.Field<string>("Imgurl"),
                                     Activity_Date = rf1.Field<string>("Activity_Date"),
                                     OrderTyp = rf1.Field<string>("OrderTyp"),
                                     POB_Value = rf1.Field<Double>("POB_Value"),
                                     Session = rf1.Field<string>("Session"),
                                     latlong = rf1.Field<string>("latlong"),
                                     net_weight_value = rf1.Field<Double>("net_weight_value"),
                                     stockist_name = rf1.Field<string>("stockist_name"),
                                     Activity_Remarks = rf1.Field<string>("Activity_Remarks"),
                                     Product_Code = (temp5tb == null ? string.Empty : temp5tb.Field<string>("Product_Code")),
                                     Quantity = (temp5tb == null ? 0 : temp5tb.Field<Int32>("Quantity")),
                                     value = (temp5tb == null ? 0 : temp5tb.Field<Double>("value"))
                                 }).ToList();

        rs4 = LINQResultToDataTable(JoinResultProdDts);

        ProdCode = new string[] { };
        DataView dv = new DataView(rs4);
        DataTable dtt = dv.ToTable(true, "Product_Code");
        ProdCode = dtt.Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray();

        finaldt = rs4;
        return JsonConvert.SerializeObject(rs3);*/
        
            var JoinResultProdDts = (from rf1 in DCR_All_dt.AsEnumerable()
                                     join t6 in DCR_Customer_dt.AsEnumerable()
                                     on new
                                     {
                                         JoinProperty1 = rf1.Field<string>("sf_code"),
                                         JoinProperty2 = rf1.Field<string>("dt"),
                                         JoinProperty3 = rf1.Field<Decimal>("Cust_Code")
                                     }
                                     equals
                                     new
                                     {
                                         JoinProperty1 = t6.Field<string>("sf_code"),
                                         JoinProperty2 = t6.Field<string>("dt"),
                                         JoinProperty3 = t6.Field<Decimal>("Cust_Code")
                                     } into tempJoin5tb
                                     from temp5tb in tempJoin5tb.DefaultIfEmpty()

                                     select new
                                     {
                                         Sf_Name = rf1.Field<string>("Sf_Name"),
                                         sf_code = rf1.Field<string>("sf_code"),
                                         Sf_Joining_Date = rf1.Field<string>("Sf_Joining_Date"),
                                         Reporting_Sf = rf1.Field<string>("Reporting_Sf"),
                                         Reporting = rf1.Field<string>("Reporting"),
                                         Designation = rf1.Field<string>("Designation"),
                                         dt = rf1.Field<string>("dt"),
                                         Wtype = rf1.Field<string>("Wtype"),
                                         remarks = rf1.Field<string>("remarks"),
                                         ClstrName = rf1.Field<string>("ClstrName"),
                                         Route = rf1.Field<string>("Route"),
                                         Imgurl = rf1.Field<string>("Imgurl"),
                                         Activity_Date = rf1.Field<string>("Activity_Date"),
                                         OrderTyp = rf1.Field<string>("OrderTyp"),
                                         POB_Value = rf1.Field<Double>("POB_Value"),
                                         Session = rf1.Field<string>("Session"),
                                         latlong = rf1.Field<string>("latlong"),
                                         net_weight_value = rf1.Field<Double>("net_weight_value"),
                                         stockist_name = rf1.Field<string>("stockist_name"),
                                         Activity_Remarks = rf1.Field<string>("Activity_Remarks"),                                      
                                         Cust_Code = (temp5tb == null ? 0 : temp5tb.Field<Decimal>("Cust_Code")),
                                         Cust_Name = (temp5tb == null ? string.Empty : temp5tb.Field<string>("Cust_Name")),
                                         Cust_Addr = (temp5tb == null ? string.Empty : temp5tb.Field<string>("Cust_Addr")),
                                         Cust_Cls = (temp5tb == null ? string.Empty : temp5tb.Field<string>("Cust_Cls")),
                                         Cust_Spec = (temp5tb == null ? string.Empty : temp5tb.Field<string>("Cust_Spec")),
                                     }).ToList();

        rs4 = LINQResultToDataTable(JoinResultProdDts);
        return JsonConvert.SerializeObject(rs4);
    }
    public static DataTable LINQResultToDataTable<T>(IEnumerable<T> Linqlist)
    {
        DataTable dt = new DataTable();
        PropertyInfo[] columns = null;
        if (Linqlist == null) return dt;
        foreach (T Record in Linqlist)
        {
            if (columns == null)
            {
                columns = ((Type)Record.GetType()).GetProperties();
                foreach (PropertyInfo GetProperty in columns)
                {
                    Type IcolType = GetProperty.PropertyType;
                    if ((IcolType.IsGenericType) && (IcolType.GetGenericTypeDefinition()
                    == typeof(Nullable<>)))
                    {
                        IcolType = IcolType.GetGenericArguments()[0];
                    }
                    dt.Columns.Add(new DataColumn(GetProperty.Name, IcolType));
                }
            }
            DataRow dr = dt.NewRow();
            foreach (PropertyInfo p in columns)
            {
                dr[p.Name] = p.GetValue(Record, null) == null ? DBNull.Value : p.GetValue(Record, null);
            }
            dt.Rows.Add(dr);
        }
        return dt;
    }
}
